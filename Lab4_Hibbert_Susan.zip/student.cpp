/********************************************************************************** 
 ** Program Name: Source code for the member functions of the child class Student
 ** Author:       Susan Hibbert
 ** Date:         25 April 2019
 ** Description:  This program contains the member function definitions for the
		  child class Student
 ** Citations:	  How do I print a double value with full precision using cout,
		  Stack Overflow
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
		  C++ discards qualifiers, Stack Overflow
 ** *******************************************************************************/ 
#include "student.hpp"
#include "person.hpp"
#include <string>
#include <cstdlib>
#include <iostream>
#include <iomanip>


/********************************************************************************** 
 ** Description: The default construtor for the Student class sets its double data
		 member GPA and the string and int data members, name and age, it
		 inherited from the Person class to default values upon
		 instantiation of a newly constructed Student object
 ** *******************************************************************************/ 

Student::Student()
{
	this -> GPA = 0.0;
	this -> set_name("Name");
	this -> set_age(0);
}


/********************************************************************************** 
 ** Description: A constructor for the Student class which takes 3 parameters - one
		 string parameter to set the string data member name inherited from
		 the Person class, one int parameter to set the int data member age
		 inherited from the Parent class, and one double parameter to set
		 the double data member GPA of the Student class
 ** *******************************************************************************/ 

Student::Student(std::string input_name, double input_GPA, int input_age)
{
	this -> set_name(input_name); //Person function
	this -> set_GPA(input_GPA);
	this -> set_age(input_age); //Person function
}

/********************************************************************************** 
 ** Description: The get_GPA function of the Student class takes no parameters and
		 returns the double data member GPA which represents the student's
		 GPA
 ** *******************************************************************************/ 

double Student::get_GPA()
{
	return this -> GPA;

}


/********************************************************************************** 
 ** Description: The set_GPA function of the Student class has no return type
		 and takes one double parameter which it uses to set the double
		 data member GPA which represents the student's GPA
 ** *******************************************************************************/ 

void Student::set_GPA(double input_GPA)
{
	this -> GPA = input_GPA;

}


/********************************************************************************** 
 ** Description: The get_type function of the Student class is an overridden function
		 of the Person class. It takes no parameters and returns the string
		 "Student" which indicates that it is a Student object
 ** *******************************************************************************/ 

std::string Student::get_type()
{
	return "Student";
}


/********************************************************************************** 
 ** Description: The do_work function of the Student class takes no parameters
		 and has no return type. It is an overridden function of the Person
		 class where it is defined as a pure virtual function. This function
		 generates a random number that represents how many hours a week 
		 the student will spend on homework, between 1 and 50 hours.
		 It then displays a message on screen including the Student's name
		 and how many hours of homework they did that week 
 ** *******************************************************************************/ 

void Student::do_work()
{
	int hours = rand() % 50 + 1;
	std::string student_name = this -> get_name();

	std::cout << " " << std::endl;	
	std::cout << student_name << " did " << hours << " hours of homework." <<std::endl;	

}

/********************************************************************************** 
 ** Description: The print_info function of the Student class takes no parameters
		 and has no return type. It is an overridden function of the Person
		 class where it is defined as a pure virtual function. It displays
		 information on the screen about the Student object - its name, age
		 and GPA
 ** *******************************************************************************/ 

void Student::print_info()
{
	std::cout << "Student name: " << this -> get_name() << std::endl;		
	std::cout << "Student age: " << this -> get_age() << std::endl;	
	std::cout << "Student GPA: " << std::fixed << std::setprecision(1)
		  << this -> get_GPA() << std::endl;
}
