/******************************************************************************* 
 ** Program Name: Header file for the display_menu function used in OSU Information
		  System
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the function prototype for the display_menu
		  function
 ** *******************************************************************************/ 
#ifndef MENU_HPP
#define MENU_HPP
#include "university.hpp"

int display_menu(University *obj);

#endif
