/********************************************************************************** 
 ** Program Name: Source code for the member functions of the University class
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the member function definitions for the
		  University class
 ** Citations:	  6.14 Pointers to pointers and dynamic multidimensional arrays,
		  LearnCpp.com
		  Dynamically allocate an array of Pointers to class objects, 
		  cplusplus.com		
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
		  C++ discards qualifiers, Stack Overflow
 ** *******************************************************************************/ 
#include "university.hpp"
#include "building.hpp"
#include "person.hpp"
#include "student.hpp"
#include "instructor.hpp"
#include <string>
#include <iostream>


/********************************************************************************** 
 ** Description: The default construtor for the University class sets the name of
		 the university to "Oregon State University" and dynamically
		 allocates an array of 2 Building pointers and dynamically allocates
		 an array of 2 Person pointers. Each Building pointer is dynamically 
		 allocated a Building object which invokes the constructor of the 
		 Building class that takes 3 parameters. One Person pointer is 
		 dynamically allocated a Student object and the other is dynamically
		 allocated an Instructor object. The constructor which takes 3
		 parameters is invoked for both the Student and Instructor objects
 ** *******************************************************************************/ 

University::University()
{
	this -> name = "Oregon State University";
	buildings = new Building*[2];
	people = new Person*[2];
	
	people[0] = new Student("Susan Hibbert", 4.0, 32);
	people[1] = new Instructor("Luyao Zhang", 5.0, 40);

	buildings[0] = new Building("Apiary Building", 2996.0, "844 SW 35th St");
	buildings[1] = new Building("Oak Creek Lab", 3617.0, "8840 NW Oak Creek Drive");
}


/********************************************************************************** 
 ** Description: The destructor for the University class frees the dynamically
		 allocated memory allocated by the default constructor for the 
		 Building pointers and Person pointers to the Building, Student
		 and Instructor objects
 ** *******************************************************************************/ 

University::~University()
{	
	delete buildings[0];
	delete buildings[1];
	delete[] buildings;

	delete people[0];
	delete people[1];
	delete[] people;
}


/********************************************************************************** 
 ** Description: The print_buildings function of the University class takes no
		 parameters and has no return type. It displays information on
		 all the university buildings in its information system including
		 the name of the building, its size and its address
 ** *******************************************************************************/ 

void University::print_buildings()
{	
	int building_number = 2;
	std::cout << " " << std::endl;
	std::cout << "**********OSU BUILDING INFORMATION**********" << std::endl;
	std::cout << " " << std::endl;

	for (int i = 0; i < building_number; ++i)
	{
		std::cout << " " << std::endl;
		std::cout << "***BUILDING NUMBER " << i + 1 << "***" << std::endl;
		buildings[i] -> print_info();
		
	}
}



/********************************************************************************** 
 ** Description: The print_people function of the University class takes no parameters
		 and has no return type. It displays information on all the people
		 at the university including their name and age. If the person is a 
		 student, it also displays the student's GPA and if the person is an	
		 instructor it displays the instructor's rating
 ** *******************************************************************************/ 

void University::print_people()
{
	int person_number = 2;
	std::cout << " " << std::endl;
	std::cout << "**********OSU PEOPLE INFORMATION**********" << std::endl;
	std::cout << " " << std::endl;

	for (int i = 0; i < person_number; ++i)
	{
		people[i] -> print_info();
		std::cout << " " << std::endl;
	}
}


/********************************************************************************** 
 ** Description: The print_name function of the University class takes no parameters
		 and has no return type. It displays the names of all the people
		 at the university and it is called when option 3 is selected in the
		 main menu
 ** *******************************************************************************/ 

void University::print_name()
{
	int person_number = 2;
	std::cout << " " << std::endl;
	std::cout << "**********CHOOSE A PERSON TO DO WORK**********" << std::endl;
	std::cout << " " << std::endl;

	for (int i = 0; i < person_number; ++i)
	{	
		std::cout << i + 1 << "." << people[i] -> get_name() << std::endl;		
	}
	
	std::cout << " " << std::endl;
}


/********************************************************************************** 
 ** Description: The get_name function of the University class takes no parameters
		 and returns the string data member name which is set by the default
		 constructor and should remain constant i.e. Oregon State University
 ** *******************************************************************************/ 

std::string University::get_name() const
{
	return this -> name;
}


/********************************************************************************** 
 ** Description: The get_people function of the University class takes no parameters
		 and returns people, the pointer to the array of Person pointers
 ** *******************************************************************************/ 

Person** University::get_people()
{
	return this -> people;
	
}
