/********************************************************************************** 
 ** Program Name: Source code for the member functions of the polymorphic, abstract
		  base class Person
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the member function definitions for the
		  abstract base class Person
 ** *******************************************************************************/ 
#include "person.hpp"
#include <string>
#include <iostream>
#include <cstdlib>


/********************************************************************************** 
 ** Description: The set_name function of the Person class has no return type
		 and takes one string parameter which it uses to set the string
		 data member name which represents the name of the person
 ** *******************************************************************************/ 

void Person::set_name(std::string input_name)
{
	this -> name = input_name;

}


/********************************************************************************** 
 ** Description: The set_age function of the Person class has no return type
		 and takes one int parameter which it uses to set the int
		 data member age which represents the age of the person in years
 ** *******************************************************************************/ 

void Person::set_age(int input_age)
{
	this -> age = input_age;

}


/********************************************************************************** 
 ** Description: The get_name function of the Person class takes no parameters
		 and returns the string data member name which represents the name
		 of the person
 ** *******************************************************************************/ 

std::string Person::get_name()
{
	return this -> name;

}


/********************************************************************************** 
 ** Description: The get_age function of the Person class takes no parameters
		 and returns the int data member age which represents the age
		 of the person in years
 ** *******************************************************************************/ 

int Person::get_age()
{
	return this -> age;

}


/********************************************************************************** 
 ** Description: The get_type function of the Person class takes no parameters
		 and returns the string "Person" to indicate the type of the Person
		 object. It will be overridden in the child classes Student and
		 Instructor
 ** *******************************************************************************/ 

std::string Person::get_type()
{
	return "Person";

}




