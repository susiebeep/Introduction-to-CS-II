/******************************************************************************* 
 ** Program Name: Main program module for OSU Information System
 ** Author:       Susan Hibbert
 ** Date:         25 April 2019
 ** Description:  This is the main program module for the OSU Information System.
		  A University object is created at the start of the program which
		  is passed to the display_menu function where the user selects from
		  a list of menu options for the Information System. After the user 
		  has made their menu choice, it is returned to the main program 
		  module and as long as they have not selected to exit the program
		  the menu will display on screen again.
		  The random number function rand used in the do_work functions
		  of the Student and Instructor classes becomes seeded with a value
		  by the srand function at the start of the main program module.
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "university.hpp"
#include "building.hpp"
#include "person.hpp"
#include "student.hpp"
#include "instructor.hpp"
#include "menu.hpp"


int main()
{
	University OSU;
	int choice;
	
	//random number generator seed for do_work function
	unsigned seed;
	seed = time(0);
	srand(seed);

	choice = display_menu(&OSU);

	//continue to display menu while user has not selected to quit program	
	while (choice != 4)
	{
		choice = display_menu(&OSU);
	}

	return 0;
}
