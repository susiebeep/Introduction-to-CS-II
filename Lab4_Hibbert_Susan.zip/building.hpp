/******************************************************************************* 
 ** Program Name: Class declaration for class Building
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the function prototypes for the class
		  Building
 ** *******************************************************************************/ 
#ifndef BUILDING_HPP
#define BUILDING_HPP
#include <string>

class Building
{
	private:
		std::string name;
		double size;
		std::string address;		
 
	public:
		Building();
		Building(std::string input_name, double input_size, std::string input_address);
		void set_name(std::string input_name);
		void set_size(double input_size);
		void set_address(std::string input_address);
		std::string get_name();
		double get_size();
		std::string get_address();	
		void print_info();
};

#endif
