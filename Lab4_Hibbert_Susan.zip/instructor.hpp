/******************************************************************************* 
 ** Program Name: Class declaration for the child class Instructor
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the function prototypes for the child class
		  Instructor
 ** *******************************************************************************/ 
#ifndef INSTRUCTOR_HPP
#define INSTRUCTOR_HPP
#include <string>
#include "person.hpp"
	
class Instructor: public Person
{
	private:
		double rating;
 
	public:
		Instructor();
		Instructor(std::string input_name, double input_rating, int input_age);
		void do_work(); //overridden function of Person abstract base class
		void print_info(); //overridden function of the Person abstract base class
		std::string get_type(); //overridden function of Person abstract base class
		double get_rating();
		void set_rating(double input_rating);
};

#endif
