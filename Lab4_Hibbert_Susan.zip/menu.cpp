/******************************************************************************* 
 ** Program Name: Source code for the display_menu function used in OSU Information
		  System
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the function definition for the display_menu
		  function which is called by the main program module of the OSU
		  Information System program.	
		 
		  It takes one parameter - a pointer to a University object that is 
		  created in the main program module of the OSU Information System.
	
		  This function prints four options on the screen for the user. After
		  the user inputs their choice, it is validated by an input
		  validation function which returns their input as an integer. If the
		  user does not select a valid menu option they will be prompted until
		  they make a valid selection.
		
		  If the user selects option 1, information about the university
		  buildings will be displayed on screen. If they select option 2, 
		  information about people at the university will be displayed on
		  screen. If they select option 4, the program will exit.

	 	  If the user selects option 3, a separate menu will be displayed on
		  the screen listing all the people's names at the university. The user
		  will be able to select which person they would like to do work.
 		  After the user inputs their choice of person, it is validated by an
		  input validation function which returns their input as an integer. If 
		  the user does not select a valid menu option they will be prompted until
		  they make a valid selection.
			
		  At the end of the function, the user's menu choice will be returned to
		  the main program module of the OSU Information System
 ** Citations:    Chapter 4.5, Menu-Driven Programs, and
                  Chapter 6.9, Using Functions in a Menu-Driven Programs, Starting Out
		  With C++ Early Objects 9th Edition;
		  5.10 std::cin, extraction, and dealing with invalid text input, 
		  LearnCPP.com
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include "menu.hpp"
#include "input.hpp"
#include "university.hpp"
#include "building.hpp"
#include "person.hpp"
#include "instructor.hpp"
#include "student.hpp"

int display_menu(University *obj)
{
	std::string choice;
	std::string input_person;
	int valid_choice;
	int val_person;

	std::cout << " " << std::endl;
	std::cout << " " << std::endl;
	std::cout << "******************************************" << std::endl;
	std::cout << "* Welcome to the OSU Information System! *" << std::endl;
	std::cout << "******************************************" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "Please select one of the following four options:" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "1. Print information about all the buildings" << std::endl;
	std::cout << "2. Print information about people at the university" << std::endl; 
	std::cout << "3. Choose a person to do work" << std::endl;	
	std::cout << "4. Exit the program" << std::endl;
	std::getline(std::cin, choice);

	//user's input is validated and converted to an integer	
	valid_choice = int_input_val(choice);

	while (valid_choice < 1 || valid_choice > 4)
	{
		std::cout << "Oops! That isn't a valid selection. Please select 1-4." << std::endl;
		std::getline(std::cin, choice);
		valid_choice = int_input_val(choice);
	}
	
	//if user chooses to exit program
	if (valid_choice == 4)
	{
		std::cout << "You selected quit. Goodbye!" << std::endl;
	}
	
	//if user chooses to display information about the university buildings
	if (valid_choice == 1)
	{
		obj -> print_buildings();
	}

	
	//if user chooses to display information about the people at the university
	if (valid_choice == 2)
	{
		obj -> print_people();
	}

	//if the user decides to choose a person at the university to do work
	if (valid_choice == 3)
	{
		//call the University member function which prints the names of the
		//people at the university on screen
		obj -> print_name();

		Person** people = obj -> get_people();
	
		std::cout << "Enter the number of the person to do the work " << std::endl;
		std::getline(std::cin, input_person);
 
		//user's input is validated and converted to an integer
		val_person = int_input_val(input_person);		
		
		while (val_person < 1 || val_person > 2)
		{
			std::cout << "Oops! That isn't a valid selection. Please select 1 or 2." << std::endl;
			std::getline(std::cin, input_person);
			val_person = int_input_val(input_person);
		}
		
		//user's choice of person (student or instructor) calls their respective do_work function
		people[(val_person - 1)] -> do_work();
	}
	
	return valid_choice;
}

