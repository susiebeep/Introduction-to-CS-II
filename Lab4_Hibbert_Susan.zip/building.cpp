/********************************************************************************** 
 ** Program Name: Source code for the member functions of the Building class
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the member function definitions for the
		  Building class
 ** *******************************************************************************/ 
#include "building.hpp"
#include <string>
#include <iostream>
#include <iomanip>

/********************************************************************************** 
 ** Description: The default construtor for the Building class sets the data members
		 of the Building class to default values upon instantiation of
		 a new Building object
 ** *******************************************************************************/ 

Building::Building()
{
	this -> name = "Building";
	this -> size = 0.0;
	this -> address = "1 Main St";
}


/********************************************************************************** 
 ** Description: A constructor for the Building class which takes 3 parameters - one
		 string parameter to set the string data member name, one double
		 parameter to set the double data member size, and another string
		 parameter to set the string data member address
 ** *******************************************************************************/ 

Building::Building(std::string input_name, double input_size, std::string input_address)
{
	this -> set_name(input_name);
	this -> set_size(input_size);
	this -> set_address(input_address);
}

/********************************************************************************** 
 ** Description: The set_name function of the Building class has no return type
		 and takes one string parameter which it uses to set the string
		 data member name which represents the name of the building
 ** *******************************************************************************/ 

void Building::set_name(std::string input_name)
{
	this -> name = input_name;

}


/********************************************************************************** 
 ** Description: The set_size function of the Building class has no return type
		 and takes one double parameter which it uses to set the double
		 data member size which represents the size of the building in sqft
 ** *******************************************************************************/ 

void Building::set_size(double input_size)
{
	this -> size = input_size;

}


/********************************************************************************** 
 ** Description: The set_address function of the Building class has no return type
		 and takes one string parameter which it uses to set the string
		 data member address which represents the address of the building
 ** *******************************************************************************/ 

void Building::set_address(std::string input_address)
{
	this -> address = input_address;

}


/********************************************************************************** 
 ** Description: The get_name function of the Building class takes no parameters
		 and returns the string data member name which represents the name
		 of the building
 ** *******************************************************************************/ 

std::string Building::get_name()
{
	return this -> name;

}


/********************************************************************************** 
 ** Description: The get_size function of the Building class takes no parameters
		 and returns the double data member size which represents the size
		 of the building in sqft
 ** *******************************************************************************/ 

double Building::get_size()
{
	return this -> size;

}


/********************************************************************************** 
 ** Description: The get_address function of the Building class takes no parameters
		 and returns the string data member address which represents the
		 address of the building
 ** *******************************************************************************/ 

std::string Building::get_address()
{
	return this -> address;

}


/********************************************************************************** 
 ** Description: The print_info function of the Building class takes no parameters
		 and has no return type. It displays information on the screen to 
		 the user about the Building object - its name, size in square feet
		 and its address
 ** *******************************************************************************/ 

void Building::print_info()
{	
	std::cout << "Name: " << this -> get_name() << std::endl;		
	std::cout << "Size (sqft): " << std::fixed << std::setprecision(1) << this -> get_size() << std::endl;
	std::cout << "Address: " << this -> get_address() << std::endl;
}
