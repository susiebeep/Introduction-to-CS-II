/******************************************************************************* 
 ** Program Name: Class declaration for the child class Student
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the function prototypes for the child class
		  Student
 ** *******************************************************************************/ 
#ifndef STUDENT_HPP
#define STUDENT_HPP
#include <string>
#include "person.hpp"
	
class Student: public Person
{
	private:
		double GPA;
 
	public:
		Student();
		Student(std::string input_name, double input_GPA, int input_age);
		void do_work(); //overridden function of Person abstract base class
		void print_info(); //overridden function of the Person abstract base class
		std::string get_type(); //overridden function of the Person abstract base class
		double get_GPA();
		void set_GPA(double input_GPA);
};

#endif
