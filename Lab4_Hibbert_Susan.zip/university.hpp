/******************************************************************************* 
 ** Program Name: Class declaration for class University
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the function prototypes for the class
		  University
 ** *******************************************************************************/ 
#ifndef UNIVERSITY_HPP
#define UNIVERSITY_HPP
#include "building.hpp"
#include "person.hpp"
#include <string>

class University
{
	private:
		std::string name;
		Building **buildings; //pointer to an array of Building pointers
		Person **people; //pointer to an array of Person pointers	
 
	public:
		University();
		~University();
		void print_buildings();
		void print_people();
		void print_name();
		std::string get_name() const;
		Person** get_people();
		
				

};

#endif
