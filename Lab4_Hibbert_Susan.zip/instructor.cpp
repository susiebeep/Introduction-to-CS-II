/********************************************************************************** 
 ** Program Name: Source code for the member functions of the child class Instructor
 ** Author:       Susan Hibbert
 ** Date:         25 April 2019
 ** Description:  This program contains the member function definitions for the
		  Instructor class
 ** Citations:	  How do I print a double value with full precision using cout,
		  Stack Overflow
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
		  C++ discards qualifiers, Stack Overflow
 ** *******************************************************************************/ 
#include "instructor.hpp"
#include "person.hpp"
#include <string>
#include <iostream>
#include <cstdlib>
#include <iomanip>


/********************************************************************************** 
 ** Description: The default construtor for the Instructor class sets its double
		 data member rating and the string and int data members, name and age,
		 it inherited from the Person class to default values upon
		 instantiation of a newly constructed Instructor object
 ** *******************************************************************************/ 

Instructor::Instructor()
{
	this -> rating = 0.0;
	this -> set_name("Name");
	this -> set_age(0);
}


/********************************************************************************** 
 ** Description: A construtor for the Instructor class which takes 3 parameters - one
		 string parameter to set the string data member name inherited from
		 the Person class, one int parameter to set the int data member age
		 inherited from the Person class, and one double parameter to set
		 the double data member rating of the Instructor class
 ** *******************************************************************************/ 

Instructor::Instructor(std::string input_name, double input_rating, int input_age)
{
	this -> set_name(input_name); //Person function
	this -> set_rating(input_rating);
	this -> set_age(input_age); //Person function
}


/********************************************************************************** 
 ** Description: The get_rating function of the Instructor class takes no parameters
		 and returns the double data member rating which represents the
		 instructor's rating
 ** *******************************************************************************/ 

double Instructor::get_rating()
{
	return this -> rating;

}


/********************************************************************************** 
 ** Description: The set_rating function of the Instructor class has no return type
		 and takes one double parameter which it uses to set the double
		 data member rating which represents the instructor's rating
 ** *******************************************************************************/ 

void Instructor::set_rating(double input_rating)
{
	this -> rating = input_rating;

}


/********************************************************************************** 
 ** Description: The get_type function of the Instructor class is an overridden function
		 of the Person class. It takes no parameters and returns the string
		 "Instructor" which indicates that it is an Instructor object
 ** *******************************************************************************/ 

std::string Instructor::get_type()
{
	return "Instructor";
}


/********************************************************************************** 
 ** Description: The do_work function of the Instructor class takes no parameters and
		 has no return type. It is an overridden function of the Person class
		 where it is defined as a pure virtual function. This function 
		 generates a random number that represents how many hours a week the
		 instructor will spend grading papers, between 1 and 50 hours. It then
		 displays a message on screen including the instructor's name and how
		 many hours they spent grading papers that week
 ** *******************************************************************************/ 

void Instructor::do_work()
{
	int hours = rand() % 50 + 1;
	std::string instructor_name = this -> get_name();

	std::cout << " " << std::endl;	
	std::cout << instructor_name << " graded papers for " << hours << " hours." << std::endl;

}


/********************************************************************************** 
 ** Description: The print_info function of the Instructor class takes no parameters
		 and has no return type. It is an overridden function of the Person
		 class where it is defined as a pure virtual function. It displays
		 information on the screen about the Instructor object - its name,
		 age and rating
 ** *******************************************************************************/ 

void Instructor::print_info()
{
	std::cout << "Instructor name: " << this -> get_name() << std::endl;		
	std::cout << "Instructor age: " << this -> get_age() << std::endl;
	std::cout << "Instructor rating: " << std::fixed << std::setprecision(1)
		  << this -> get_rating() << std::endl;
}
