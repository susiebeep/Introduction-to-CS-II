/******************************************************************************* 
 ** Program Name: Class declaration for polymorphic, abstract base class Person
 ** Author:       Susan Hibbert
 ** Date:         23 April 2019
 ** Description:  This program contains the function prototypes for the abstract
		  base class Person
 ** *******************************************************************************/ 
#ifndef PERSON_HPP
#define PERSON_HPP
#include <string>

class Person
{
	private:
		std::string name;
		int age;
 
	public:
		void set_name(std::string input_name);
		void set_age(int input_age);
		std::string get_name();
		int get_age();
		virtual std::string get_type();
		virtual void do_work() = 0; //pure virtual function
		virtual void print_info() = 0; //pure virtual function 
};

#endif
