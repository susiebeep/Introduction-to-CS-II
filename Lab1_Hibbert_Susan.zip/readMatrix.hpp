/******************************************************************************* 
 ** Program Name: Header file for void readMatrix() function
 ** Author:       Susan Hibbert
 ** Date:         3 April 2019
 ** Description:  This program contains the function prototype for the void 
    readMatrix() function 
 ** *******************************************************************************/ 

#ifndef READMATRIX_HPP
#define READMATRIX_HPP

void readMatrix(int **array, int matrixSize);

#endif
