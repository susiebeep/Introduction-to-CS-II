/******************************************************************************* 
 ** Program Name: Source code for the int determinant() function
 ** Author:       Susan Hibbert
 ** Date:         3 April 2019
 ** Description:  This program contains the function definition for the int 
    determint()function. It takes two parameters - a pointer to a 2D array and an
    integer representing the size of the matrix. It returns the determinant of the
    matrix as an integer value. The function only works for 2x2 and 3x3 matrices of
    sizes 4 and 9 respectively.
 ** *******************************************************************************/ 
#include "determinant.hpp"


int determinant(int **array, int matrixSize)
{
	int result;

	if (matrixSize == 4)
	{
		int calc1 = (array[0][0])*(array[1][1]);
		int calc2 = (array[1][0])*(array[0][1]);
		result = calc1 - calc2;
		return result;			
	}
	
	if (matrixSize == 9)
	{
		int calc1a = (array[1][1])*(array[2][2]) - (array[1][2])*(array[2][1]);
		int calc1b = calc1a * (array[0][0]);
		int calc2a = (array[1][0])*(array[2][2]) - (array[1][2])*(array[2][0]);
		int calc2b = calc2a * (array[0][1]);
		int calc3a = (array[1][0])*(array[2][1]) - (array[1][1])*(array[2][0]);
		int calc3b = calc3a * (array[0][2]);
                result = calc1b - calc2b + calc3b;
                return result;			
	}
}
