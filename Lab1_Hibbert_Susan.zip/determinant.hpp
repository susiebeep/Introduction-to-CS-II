/******************************************************************************* 
 ** Program Name: Header file for int determinant() function 
 ** Author:       Susan Hibbert
 ** Date:         3 April 2019
 ** Description:  This program contains the function prototype for the int 
    determinant() function
 ** *******************************************************************************/ 

#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

int determinant(int **array, int matrixSize);

#endif
