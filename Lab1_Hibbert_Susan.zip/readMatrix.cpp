/******************************************************************************* 
 ** Program Name: Source code for void readMatrix() function
 ** Author:       Susan Hibbert
 ** Date:         3 April 2019
 ** Description:  This program contains the function definition for the void 
    readMatrix()function. This function prompts the user to enter all the numbers
    within the matrix (the user will have already selected a 2x2 or 3x3 matrix in
    the main program module). It takes two parameters - a pointer to a 2D array and
    an integer representing the size of the matrix. The function is restricted to 
    2x2 and 3x3 matrices of sizes 4 and 9 respectively. As it is a void function it
    does not return anything.
 ** *******************************************************************************/ 
#include <iostream>
#include "readMatrix.hpp"

void readMatrix(int **array, int matrixSize)
{
	int row;
	int col;

	std::cout << "Please enter " << matrixSize << " numbers" << std::endl;
	
	if (matrixSize == 4)
	{
		for (int row = 0; row < 2; row++)
		{
			for (int col = 0; col < 2; col++)
			{
				std::cin >> array[row][col];
			}
		}

	}

	if (matrixSize == 9)
	{
		for (int row = 0; row < 3; row++)
		{
			for (int col = 0; col < 3; col++)
			{
				std::cin >> array[row][col];
			}
		}
	}

}

