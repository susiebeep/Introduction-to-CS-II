/******************************************************************************* 
 ** Program Name: Main program module for the matrix calculator
 ** Author:       Susan Hibbert
 ** Date:         3 April 2019
 ** Description:  This is the main program module for the matrix calculator. It asks
    the user to choose the size of a matrix (2x2 or 3x3) and dynamically allocates
    memory space for the matrix, using the readMatrix() function to prompt the user
    for 4 or 9 integers to fill the matrix. The program calculates the determinant
    of the matrix using the determinant() function and displays it to the user, along
    with the matrix in a square format. The dynamically allocated memory is freed at
    the end of the program.	
 ** *******************************************************************************/ 
#include <iostream>
#include "readMatrix.hpp"
#include "determinant.hpp"

int main()
{
	int choice;
	int row;
	int col;
	int matrixSize;
	int matrixDeterminant;
	int **array = NULL;

	std::cout << "Please choose the size of the matrix: " << std::endl; 
	std::cout << "Press 1 for a 2x2 matrix or press 2 for a 3x3 matrix" << std::endl;
        std::cin >> choice;

	if (choice == 1)
	{
		matrixSize = 4;
		int **array = new int*[2];
		for (int count = 0; count < 2; count++)
		{
			array[count] = new int[2];
		}
		
		readMatrix(array, matrixSize);

		matrixDeterminant = determinant(array, matrixSize);

		std::cout << "The matrix is as follows: " << std::endl;
		
		for (int row = 0; row < 2; row++)
		{
			for (int col = 0; col < 2; col++)
			{
				std::cout << array[row][col] << " ";		
			}
			
			std::cout << " " << std::endl;
		}

		std::cout << "The determinant of the matrix is " << matrixDeterminant << std::endl;


		for (int count = 0; count < 2; count++)
		{
			delete [] array[count];
		}

		delete [] array;
	}
	
	if (choice == 2)
	{
		matrixSize = 9;
		int **array = new int*[3];
		for (int count = 0; count < 3; count++)
		{
			array[count] = new int[3];
		}
		
		readMatrix(array, matrixSize);

		matrixDeterminant = determinant(array, matrixSize);

		
		std::cout << "The matrix is as follows: " << std::endl;
		
		for (int row = 0; row < 3; row++)
		{
			for (int col = 0; col < 3; col++)
			{
				std::cout << array[row][col] << " ";	
			}
			
			std::cout << " " << std::endl;
		}

		std::cout << "The determinant of the matrix is " << matrixDeterminant << std::endl;

		for (int count = 0; count < 3; count++)
		{
			delete [] array[count];
		}

		delete [] array;
	}

	return 0;
}
