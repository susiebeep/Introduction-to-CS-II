/********************************************************************************** 
 ** Program Name: Source code for the member functions of the class Queue and 
		  constructors for the struct QueueNode
 ** Author:       Susan Hibbert
 ** Date:         13 May 2019
 ** Description:  This program contains the member function definitions for the
		  class Queue and constructors for the struct QueueNode
 ** Citations: 	  Chapter 18 Stacks and Queues, Starting Out With C++ Early Objects,
		  9th Edition, Gaddis
		  Chapter 7.12 Strucures, Starting Out With C++ Early Objects,
		  9th Edition, Gaddis
		  C++ Circular Link List - remove all nodes, StackOverflow.com
 ** *******************************************************************************/ 
#include "queue.hpp"
#include <iostream>
#include <cstdlib>

/********************************************************************************** 
 ** Description: A constructor for the QueueNode struct which is called when the 
		 first QueueNode is added to the queue. It takes 1 int parameter 
		 which it uses to initialize its int data member val in a newly
		 created QueueNode object. It also sets its prev and next pointers
		 to point to itself. In a circular linked list, when there is only
		 one node, it's prev and next pointers will point back to itself, 
		 as per the definition of a circular linked list 
 ** *******************************************************************************/ 

QueueNode::QueueNode(int input_val) 
{
	val = input_val;
	prev = this;
	next = this;
}


/********************************************************************************** 
 ** Description: A constructor for the QueueNode struct which is called when there
		 is at least 1 QueueNode in the queue already. It takes 3 parameters
		 to initialize the data members in a newly created QueueNode object.
		 It takes an int parameter which it uses to initialize its int data
		 member val, and takes two QueueNode pointer parameters which it uses
		 to initialize its prev and next QueueNode pointer data members
		 respectively
 ** *******************************************************************************/ 

QueueNode::QueueNode(int input_val, QueueNode *prev1, QueueNode *next1) 
{
	val = input_val;
	prev = prev1;
	next = next1;
}


/********************************************************************************** 
 ** Description: The default constructor for the Queue class initializes its 
		 QueueNode pointer data member head to null in a newly created Queue
		 object 
 ** *******************************************************************************/ 

Queue::Queue()
{
	head = NULL;
}


/********************************************************************************** 
 ** Description: isEmpty function of the Queue class takes no parameters and returns
		 a boolean indicating if the queue is empty. If it is empty, it
		 returns true. Otherwise it returns false
 ** *******************************************************************************/ 

bool Queue::isEmpty()
{

	//if the queue is empty
	if (head == NULL)
	{
		return true;
	}

	else
	{
		return false;
	}	
}


/********************************************************************************** 
 ** Description: The destructor for the Queue class deletes the dynamic memory used
		 by the QueueNodes in the circular linked list. It starts at the 
		 front node of the queue and steps through each node, deleting the
		 memory used by each QueueNode one by one, until all nodes have been
		 deleted
 ** *******************************************************************************/ 

Queue::~Queue()
{
	//start at the front of the queue
	QueueNode *ptr = head;	
	QueueNode *garbage = NULL;
	
	bool empty = isEmpty();
	
	//if queue is empty do nothing
	if (empty)
	{
		return;
	}

	else
	{	
		//delete the nodes in the queue until you circle back to the head again
		do
		{	
			//assign garbage pointer
			garbage = ptr;
	
			//set ptr to the next node in the queue
			ptr = ptr -> next;

			//set the prev and next pointers to null in the QueueNode
			//pointed at by garbage then delete the node
			garbage -> next = NULL;
			garbage -> prev = NULL;
			delete garbage;
		
		}
		while (ptr != head);

		//when loop completes set head to null
		head = NULL;
	}
}

/********************************************************************************** 
 ** Description: addBack function of the Queue class has no return type and takes 
		 an integer, inputted by the user, which it uses to set the int
		 data member val in a new QueueNode object. After creating the new
		 QueueNode object, it appends it to the back of the queue and sets
		 the adjacent QueueNode prev and next pointers, as well as the head
		 pointer, accordingly
 ** *******************************************************************************/ 

void Queue::addBack(int input_val)
{
	bool empty = isEmpty();

	//if the queue is empty
	if (empty)
	{
		//add a new QueueNode to the queue - this calls the QueueNode constructor
		//which takes one int parameter. This sets its int data member val to the
		//value input by the user and also sets its prev and next pointers to point
		//to itself as it is the only QueueNode in the queue
		head = new QueueNode(input_val);
	}
	
	else
	{
		//create pointers to first and last nodes in the queue
		QueueNode *firstNode = head;
		QueueNode *lastNode = head -> prev;
	
		//if only one QueueNode in the queue
		if (firstNode == lastNode)
		{	
			//add a new QueueNode at the end of the queue - this calls the
			//QueueNode constructor which takes 3 parameters. Its prev
			//and next pointers are set to point to the first node in the
			//queue, as per the definition of a circular linked list
			lastNode = new QueueNode(input_val, firstNode, firstNode);
		
			//set pointers of first node in the queue after new QueueNode
			//has been added to the end of the queue
			head -> prev = lastNode;
			head -> next = lastNode;
		}	

		//if 2 or more QueueNodes in the queue
		else
		{	
			//set last node in the queue as the new second last node
			QueueNode *secondLast = lastNode;
	
			//add a new QueueNode to the end of the queue, setting its prev pointer
			//to point to the second last node in the queue and its next pointer to
			//point to the head as per the definition of a circular linked list
			lastNode = new QueueNode(input_val, secondLast, firstNode);
	
			//set the second last node's next pointer and first node's prev pointer
			//after adding a new node to the end of the queue
			secondLast -> next = lastNode;
			head -> prev = lastNode;
		}
	}
}	



/********************************************************************************** 
 ** Description: getFront function of the Queue class takes no parameters and returns
		 the int data member val of the QueueNode at the front of the queue.
		 If the queue is empty the function returns -1 to the calling program
		 and an error message is displayed on screen
 ** *******************************************************************************/ 

int Queue::getFront()
{
	bool empty = isEmpty();

	//if the queue is empty
	if (empty)
	{
		return -1;
	}

	else
	{
		int front = head -> val;
		return front;
	}
}


/********************************************************************************** 
 ** Description: removeFront function of the Queue class has no return type and takes
		 no parameters. It removes the front QueueNode of the queue and frees
		 the memory dynamically allocated to it. If the queue is empty it 
		 displays a warning message to the user
 ** *******************************************************************************/ 

void Queue::removeFront()
{
	bool empty = isEmpty();

	//if queue is empty
	if (empty)
	{
		std::cout << "The queue is empty!" << std::endl;
	}
		
	else
	{	
		//create pointers to first and last nodes in the queue
		QueueNode *firstNode = head;
		QueueNode *lastNode = head -> prev;
	
		//if only one QueueNode in the queue
		if (firstNode == lastNode)
		{	
			//set first node's prev and next pointers to null as the
			//queue is now empty then delete first node
			firstNode -> prev = NULL;
			firstNode -> next = NULL;
			delete firstNode;
		
			//set head to null as queue is empty
			head = NULL;
		}	

		//if 2 or more QueueNodes in the queue
		else
		{	
			//create pointer to second node in the queue
			QueueNode *secondNode = head -> next;
	
			//set first node's prev and next pointers to null then
			//delete first node
			firstNode -> prev = NULL;
			firstNode -> next = NULL;
			delete firstNode;

			//reassign the head pointer to point to the new first node
			head = secondNode;
			
			//reassign pointers in new first node and last node of the 
			//queue	
			secondNode -> prev = lastNode;
			lastNode -> next = secondNode;
		}
	}
}

/********************************************************************************** 
 ** Description: printQueue function of the Queue class has no return type and takes
		 no parameters. It traverses through the queue from the head using 
		 next pointers and prints the int data member val of each QueueNode
		 object in the queue. If the queue is empty it displays a warning
		 message to the user
 ** *******************************************************************************/ 

void Queue::printQueue()
{
	bool empty = isEmpty();
	
	//if queue is empty
	if (empty)
	{
		std::cout << "The queue is empty!" << std::endl;
	}
		
	else
	{
		QueueNode *ptr = head;

		//starting from the head, print the QueueNode data member val in
		//current node then move onto the next QueueNode, until the end
		//of the queue is reached and you are back to the start of the
		//circular linked list
		do
		{
			std::cout << ptr -> val << " ";
			ptr = ptr -> next;
		}		
		while (ptr != head);
	}
}

