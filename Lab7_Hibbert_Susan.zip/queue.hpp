/******************************************************************************* 
 ** Program Name: Class declaration for class Queue and struct QueueNode
 ** Author:       Susan Hibbert
 ** Date:         13 May 2019
 ** Description:  This program contains the function prototypes for the class Queue
		  which implements the circular linked list and struct QueueNode,
		  the data type of each node in the circular linked list
 ** *******************************************************************************/ 
#ifndef QUEUE_HPP
#define QUEUE_HPP

struct QueueNode
{		
	QueueNode *next;
	QueueNode *prev;
	int val;
	QueueNode(int input_val); //called when the first QueueNode is added to the queue
	QueueNode(int input_val, QueueNode *prev1, QueueNode *next1);
};

class Queue
{
	private:

		QueueNode *head;
 
	public:
		Queue();
		~Queue();
		bool isEmpty();
		void addBack(int input_val);
		int getFront();
		void removeFront();
		void printQueue();
		
};

#endif
