/******************************************************************************* 
 ** Program Name: Source code for the display_menu function used in Circular-Linked
		  List Program
 ** Author:       Susan Hibbert
 ** Date:         13 May 2019
 ** Description:  This program contains the function definition for the
		  display_menu function which is called by the main program module
		  of the Circular- Linked List Program.	
	
		  This function prints 5 options on the screen for the user. After
		  the user inputs their choice, it is validated by an input
		  validation function which returns their input as an integer. If
		  the user does not select a valid menu option they will be 
		  prompted until they make a valid selection.				

		  If the user selects option 1, they will be prompted to enter a
		  positive integer. After the user inputs their selection, it is
		  validated by an input validation function which returns their
		  input as an integer. Their input is passed to the addBack
		  function which adds a value to the back of the queue.
		 
		  If the user selects option 2, the getFront function is called
		  which returns the value of the node at the front of the queue.
		  If the queue is empty a warning message will be displayed on
		  screen.
 
		  If the user selects option 3, the removeFront function will be
		  called which removes the front QueueNode in the queue. If the
		  queue is empty a warning message will appear on screen.

		  If the user selects option 4, the printQueue function will be
		  called which prints out the value of each QueueNode in the queue.
		  If the queue is empty a warning message will appear on screen.
	
		  If the user selects option 5, the program will exit.
			
		  At the end of function, the user's menu choice will be returned
		  to the main program module of the Circular-Linked List Program
 ** Citations:    Chapter 4.5, Menu-Driven Programs, and
                  Chapter 6.9, Using Functions in a Menu-Driven Programs, Starting 
		  Out With C++ Early Objects 9th Edition;
		  5.10 std::cin, extraction, and dealing with invalid text input, 
		  LearnCPP.com
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include "menu.hpp"
#include "input.hpp"
#include "queue.hpp"

int display_menu(Queue *obj)
{
	std::string choice;
	std::string input1;
	int valid_choice;
	int valid_choice1;

	std::cout << " " << std::endl;
	std::cout << " " << std::endl;
	std::cout << "********************************" << std::endl;
	std::cout << "*  CIRCULAR-LINKED LIST PROGRAM *" << std::endl;
	std::cout << "*********************************" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "Please select one of the following five options:" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "1. Enter a value to be added to the back of the queue" << std::endl;
	std::cout << "2. Display first node (front) value" << std::endl; 
	std::cout << "3. Remove first node (front) value" << std::endl;	
	std::cout << "4. Display the queue's contents" << std::endl;
	std::cout << "5. Exit" << std::endl;
	std::getline(std::cin, choice);

	//user's input is validated and converted to an integer	
	valid_choice = int_input_val(choice);

	while (valid_choice < 1 || valid_choice > 5)
	{
		std::cout << "Oops! That isn't a valid selection. Please select 1-5." << std::endl;
		std::getline(std::cin, choice);
		valid_choice = int_input_val(choice);
	}
	
	//if user chooses to exit program
	if (valid_choice == 5)
	{
		std::cout << " " << std::endl;
		std::cout << "You selected quit. Goodbye!" << std::endl;
	}
	
	//if user chooses option 1
	if (valid_choice == 1)
	{
		std::cout << " " << std::endl;
		std::cout << "Please enter a positive integer:" << std::endl;
		std::getline(std::cin, input1);
	
		//user's input is validated and converted to an integer
		valid_choice1 = int_input_val(input1);
	
		//call addBack function with valid_choice1 as parameter to add a node to the 
		//back of the queue	
		obj -> addBack(valid_choice1);
	
	}

	//if user chooses option 2
	if (valid_choice == 2)
	{
		//call getFront function to return the value of the node at the front of the queue
		int front = obj -> getFront();
	
		//if the queue is empty
		if (front == -1)
		{	
			std::cout << " " << std::endl;
			std::cout << "The queue is empty!" << std::endl;
		}
	
		else
		{
			std::cout << " " << std::endl;
			std::cout << "The first node value is: " << front << std::endl;
		}
	}

	//if the user chooses option 3
	if (valid_choice == 3)
	{
		std::cout << " " << std::endl;
		std::cout << "Removing front node..." << std::endl;
			
		//call removeFront function to delete first node in the queue
		//if queue is empty display a warning message
		obj -> removeFront();

	}
	
	//if the user chooses option 4
	if (valid_choice == 4)
	{
		std::cout << " " << std::endl;
		std::cout << "Your queue is: " << std::endl;
			
		//call printQueue function to print values of each QueueNode in the queue
		obj -> printQueue();
	}


	return valid_choice;
}

