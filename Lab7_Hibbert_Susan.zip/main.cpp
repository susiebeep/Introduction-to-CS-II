/******************************************************************************* 
 ** Program Name: Main program module for Circular-Linked List Program
 ** Author:       Susan Hibbert
 ** Date:         13 May 2019
 ** Description:  This is the main program module for the Circular-Linked List
		  Program. A Queue object is created which is passed to the
		  display_menu function which provides the user with a list of 
		  menu options they can choose for the queue, or they can exit
		  the program. After the user has made their menu choice, it is 
		  returned to the main program module and as long as they have
		  not selected to exit the program the menu will display on screen
		  again.
 ** *******************************************************************************/ 
#include <iostream>
#include "menu.hpp"
#include "queue.hpp"

int main()
{
	Queue queue;
	int choice;
	
	choice = display_menu(&queue);

	//continue to display menu while user has not selected to quit program	
	while (choice != 5)
	{
		choice = display_menu(&queue);
	}

	return 0;
}
