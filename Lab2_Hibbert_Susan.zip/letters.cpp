/********************************************************************************** 
 ** Program Name: Source code for count_letters and output_letters functions
 ** Author:       Susan Hibbert
 ** Date:         11 April 2019
 ** Description:  This program contains the function definitions for count_letters()
		  and output_letters() functions
 ** Citations:	  Converting a string to upper and lower case in C++ using STL and
		  Boost Library, thispointer.com
		  Chapter 13, Advanced File and I/O Operations, Starting Out With C++
		  Early Objects, 9th Edition, Gaddis
		  The ASCII Character Set, Appendix A, Starting Out with C++ Early
		  Objects, 9th Edition, Gaddis
 ** *******************************************************************************/ 
#include "letters.hpp"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <algorithm>


/********************************************************************************** 
 ** Description: The output_letters function takes 2 parameters - an output file
		 stream variable and a pointer to an array of integers that contains
		 the frequencies of the letters. The function first asks the user
		 for the filename they would like to output to, then it outputs the
		 frequencies of letters to this output file. Each paragraph in the
		 input file has its own output file
 ** *******************************************************************************/ 

void output_letters(std::ofstream& ofs, int* int_array)
{
	std::string output_file;	

	std::cout << "Please enter the filename you would like to output to:" << std::endl;
	std::cin >> output_file;	
	
	ofs.open(output_file, std::ios::out);		
	
	//if the output file opens successfully, output the letter frequencies
	//from the array into the output file, with each letter having its own
	//line and description of the letter e.g. 'a: 2' etc. If the output file
	//fails to open an error message will be displayed to the user
	if (!ofs.fail())
	{
		for (int i = 0; i < 26; i++)
		{
			ofs  << char('a'+ i) << ": ";
			ofs << int_array[i] << std::endl;
		}
	}
	else
	{
		std::cout << "Output file failed to open" << std::endl;
	}

	ofs.close();
}


/********************************************************************************** 
 ** Description: The count_letters function takes 2 parameters - an input file
		 stream variable and a pointer to an array of integers. The function
		 reads the first paragraph string from the input file then converts 
		 all the characters in the string to lowercase. Then it counts
		 the frequencies of each letter in that paragraph and stores the
		 frequencies in the array in the letter's corresponding array position.
		 Then, the array is passed to the count_letters function and the
		 array is cleared before the next iteration of the while loop moves
		 onto the next paragraph of the input file
 ** *******************************************************************************/ 

void count_letters(std::ifstream& ifs, int *int_array)
{
	std::string current_line;
	std::ofstream ofs;
	
	while(std::getline(ifs, current_line))
	{	
		//convert current_line to all lowercase letters
		std::for_each(current_line.begin(), current_line.end(), [](char & c)
		{	
			c = ::tolower(c);
		});	

		//iterate through current_line and count the occurence of
		//each letter using its ASCII code number - subtract the ASCII
		//code for 'a' from the letter's ASCII code to determine its
		//array index. For instance, the total number of a's is stored
		//in array index 0, total number of b's is stored in array
		//index 1 and so on.
		for (int i = 0; i < current_line.length();  i++)	
		{
			int index = current_line.at(i) - 'a';
			if (index >= 0 && index <= 26)
			{
				int_array[index] += 1;			
			}
		}
	
		//pass array to output_letters function
		output_letters(ofs, int_array);
	
		//clear the array before moving onto the next paragraph	
		for (int i = 0; i < 26; i++)
		{
			int_array[i] = 0;
		}
	}

}









