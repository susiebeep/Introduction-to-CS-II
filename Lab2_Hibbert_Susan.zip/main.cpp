/******************************************************************************* 
 ** Program Name: Main program module for lab2
 ** Author:       Susan Hibbert
 ** Date:         11 April 2019
 ** Description:  This is the main program module for lab2. In this program,
		  the user specifies a file they would like to read which is 
		  filled with letters. The program counts the letter frequencies
		  in this file and writes the results to a new file. Each paragraph
		  in the input file has its own output file
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include <fstream>
#include "letters.hpp"

int main()
{
	std::ifstream ifs;
	int *int_array = new int[26];
	std::string input_file;

	//initialize the dynamically allocated array before passing it
	//into the count_letters function
	for (int i = 0; i < 26; i++)
	{	
		int_array[i] = 0;
	} 

	std::cout << "Please enter the name of the file you would like to read" << std::endl;
	std::cin >> input_file;
	
	ifs.open(input_file, std::ios::in);
	
	//if the input file specified by the user does not exist
	//display error message to the user
	if (ifs.fail())
	{	
		std::cout << "The file was not found!" << std::endl;
	}

	count_letters(ifs, int_array);

	ifs.close();
	
	//free the dynamically allocated memory for the array
	delete [] int_array;

	return 0;
}
