/******************************************************************************* 
 ** Program Name: Header file for count_letters and output_letters functions 
 ** Author:       Susan Hibbert
 ** Date:         11 April 2019
 ** Description:  This program is the header file containing the function prototypes
		  for the count_letters function and output_letters function
 ** *******************************************************************************/ 
#include <fstream>
#include <iostream>
#ifndef LETTERS_HPP
#define LETTERS_HPP

void count_letters(std::ifstream& ifs, int *int_array);
void output_letters(std::ofstream& ofs, int *int_array);

#endif
