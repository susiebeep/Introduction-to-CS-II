/******************************************************************************* 
 ** Program Name: Main program module for Doubly-Linked List Program
 ** Author:       Susan Hibbert
 ** Date:         7 May 2019
 ** Description:  This is the main program module for the Doubly-Linked List
		  Program. The display_menu function is called which provides the
		  user with a list of options they can choose, or they can exit
		  the program. After the user has made their menu choice, it is 
		  returned to the main program module and as long as they have
		  not selected to exit the program the menu will display on screen
		  again.
 ** *******************************************************************************/ 
#include <iostream>
#include "menu.hpp"
#include "doublylinkedlist.hpp"

int main()
{
	DoublyLinkedList list;
	int choice;
	
	choice = display_menu(&list);

	//continue to display menu while user has not selected to quit program	
	while (choice != 8)
	{
		choice = display_menu(&list);
	}

	return 0;
}
