/********************************************************************************** 
 ** Program Name: Source code for the member functions of the class Node
 ** Author:       Susan Hibbert
 ** Date:         7 May 2019
 ** Description:  This program contains the member function definitions for the
		  class Node
 ** Citations:	  Chapter 17 Linked Lists, Starting Out With C++ Early Objects,
		  9th Edition, Gaddis
 ** *******************************************************************************/ 
#include "node.hpp"
#include <cstdlib>

/********************************************************************************** 
 ** Description: The default constructor for the Node class initializes its data
		 members upon creation of a new Node object
 ** *******************************************************************************/ 

Node::Node()
{
	this -> val = 0;
	prev = NULL;
	next = NULL;

}


/********************************************************************************** 
 ** Description: A constructor for the Node class which takes 3 parameters. It takes
		 an int parameter which is uses to set the value of its int data
		 member val representing an integer value specific to the Node. It
		 takes two Node pointer parameters which it uses to set its Node
		 pointer data members prev and next which represent pointers to the
		 previous and next Node objects in a doubly-linked list
 ** *******************************************************************************/ 

Node::Node(int val1, Node *prev1, Node *next1)
{
	val = val1;
	prev = prev1;
	next = next1;
}


/********************************************************************************** 
 ** Description: get_val function of the Node class takes no parameters and returns
		 the int data member val representing an integer value specific to
		 the Node object
 ** *******************************************************************************/ 

int Node::get_val()
{
	return this -> val;
}


/********************************************************************************** 
 ** Description: set_val function of the Node class has no return type and takes
		 an int parameter and uses this value to set the int data member val
		 representing an integer value specific to the Node object
 ** *******************************************************************************/ 

void Node::set_val(int input_val)
{
	this -> val = input_val;
}


/********************************************************************************** 
 ** Description: get_prev function of the Node class takes no parameters and returns
		 the Node pointer prev representing a pointer to the previous Node
		 object
 ** *******************************************************************************/ 

Node* Node::get_prev()
{
	return this -> prev;
}


/********************************************************************************** 
 ** Description: get_next function of the Node class takes no parameters and returns
		 the Node pointer next representing a pointer to the next Node object
 ** *******************************************************************************/ 

Node* Node::get_next()
{
	return this -> next;
}


/********************************************************************************** 
 ** Description: set_prev function of the Node class has no return type and takes
		 a Node pointer as a parameter which it uses to set the data member 
		 prev representing a pointer to the previous Node object
 ** *******************************************************************************/ 

void Node::set_prev(Node* input_prev)
{
	this -> prev = input_prev;
}


/********************************************************************************** 
 ** Description: set_next function of the Node class has no return type and takes
		 a Node pointer as a parameter which it uses to set the data member 
		 next representing a pointer to the next Node object
 ** *******************************************************************************/ 

void Node::set_next(Node* input_next)
{
	this -> next = input_next;
}
