/******************************************************************************* 
 ** Program Name: Class declaration for class DoublyLinkedList
 ** Author:       Susan Hibbert
 ** Date:         7 May 2019
 ** Description:  This program contains the function prototypes for the class 
		  DoublyLinkedList
 ** *******************************************************************************/ 
#ifndef DOUBLYLINKEDLIST_HPP
#define DOUBLYLINKEDLIST_HPP
#include "node.hpp"

class DoublyLinkedList
{
	private:
		Node *head;
		Node *tail;
 
	public:
		DoublyLinkedList();
		~DoublyLinkedList();
		void function1(int input_num1);
		void function2(int input_num2);
		void function3();
		void function4();
		void function5();
		void function6();
		void print_head(); //extra credit - task 1
		void print_tail(); //extra credit - task 1
};

#endif
