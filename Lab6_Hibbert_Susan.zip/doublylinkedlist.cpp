/********************************************************************************** 
 ** Program Name: Source code for the member functions of the class DoublyLinkedList
 ** Author:       Susan Hibbert
 ** Date:         7 May 2019
 ** Description:  This program contains the member function definitions for the
		  class DoublyLinkedList
 ** Citations: 	  Chapter 17 Linked Lists, Starting Out With C++ Early Objects,
		  9th Edition, Gaddis
 ** *******************************************************************************/ 
#include "node.hpp"
#include "doublylinkedlist.hpp"
#include <iostream>
#include <cstdlib>

/********************************************************************************** 
 ** Description: The default constructor for the DoublyLinkedList class initializes
		 its Node pointers to null in a newly created DoublyLinkedList object 
 ** *******************************************************************************/ 

DoublyLinkedList::DoublyLinkedList()
{
	head = NULL;
	tail = NULL;
}


/********************************************************************************** 
 ** Description: The destructor for the DoublyLinkedList class deletes the dynamic
		 memory used by the linked list. It steps through the linked list
		 and deletes the memory used by each Node in the list one by one
 ** *******************************************************************************/ 

DoublyLinkedList::~DoublyLinkedList()
{
	//start at the beginning of the list
	Node *nodePtr = head;
	
	//while haven't reached the end of the list
	while (nodePtr != NULL)
	{
		//garbage pointer keeps track of node to be deleted
		Node *garbage = nodePtr;
		
		//move onto next node
		nodePtr = nodePtr -> get_next();
		
		//delete the node garbage is pointing at
		delete garbage;
	}
}

/********************************************************************************** 
 ** Description: function1 of the DoublyLinkedList class has no return type and takes
		 one int parameter which it uses to set the int data member val in 
		 the new Node object. It adds a new Node to the head of the list. 
		
		 The function creates a new Node with inputted value stored inside
		 and sets its prev and next pointers by calling upon a constructor 
		 of the Node class which takes 3 parameters. The new Node object is
		 added to the head of list and the head (and tail) pointers are
		 reassigned accordingly
 ** *******************************************************************************/ 

void DoublyLinkedList::function1(int input_num1)
{

	//if the list is empty
	if (head == NULL)
	{
		//add a new node to the head, set its prev pointer to null
		//and its next pointer to null as it's the only node in
		//the list
		head = new Node(input_num1, NULL, NULL);
	
		//set the tail to point to the only node in the list
		tail = head;
	}

	else
	{
		//get the node the head is currently pointing to
		Node* old_head = head;
	
		//add a new node to the head, set its prev pointer to null
		//as it's now the first node in the list and its next pointer
		//to the original first node
		head = new Node(input_num1, NULL, old_head);
		
		//set the original first node's prev pointer to point to the
		//new first node
		old_head -> set_prev(head);
	}	
}


/********************************************************************************** 
 ** Description: function2 of the DoublyLinkedList class has no return type and takes
		 one int parameter which is uses to set the int data member val in a 
		 new Node object. It adds a new Node to the tail of the list. 

	 	 The function creates a new Node with inputted value stored inside
		 and sets its prev and next pointers by calling upon a constructor of
		 the Node class which takes 3 parameters. The new Node object is
		 added to the tail of the list and the tail (and head) pointers are
		 reassigned accordingly
 ** *******************************************************************************/ 

void DoublyLinkedList::function2(int input_num2)
{
	//if the list is empty
	if (head == NULL)
	{
		//add a new node and set its prev and next pointers to null as its
		//the only node in the list 
		tail = new Node(input_num2, NULL, NULL);
		
		//set the head to point to the only node in the list
		head = tail;
	}

	else
	{
		//get the last node the tail is pointing to
		Node *old_tail = tail;
	
		//add a new node to the tail, set its prev pointer to the original
		//last node and set its next pointer to null as it's the last node
		//in the list 
		tail = new Node(input_num2, old_tail, NULL);

		//set the original last node's next pointer to point to the
		//new last node
		old_tail -> set_next(tail);
	}
}


/********************************************************************************** 
 ** Description: function3 of the DoublyLinkedList class has no return type and takes
		 no parameters. It deletes the first Node in the list. 

		 The function checks if the list is empty and if so displays a warning
		 message to the user. The function locates the first Node and deletes
		 it and frees its allocated memory. The head pointer is then reassigned,
		 along with the pointers inside the new first Node of the list
 ** *******************************************************************************/ 

void DoublyLinkedList::function3()
{
	//if list is empty
	if (head == NULL)
	{
		std::cout << "The list is empty!" << std::endl;
	}
	
	//if only one node in the list
	if (head == tail)	
	{
		delete head;
		head = NULL;
		tail = NULL;
	}	

	else
	{	
		//locate the second node in the list which is to become the first node
		Node* second = head -> get_next();

		//locate the first node in the list to be removed
		Node* first = head;

		//set head to the second node, which becomes the first node now
		head = second;
		
		//set prev pointer of new first node to NULL
		head -> set_prev(NULL);

		//if now only one node in the list
		if (head -> get_next() == NULL)
		{
			tail = head;
		}

		//delete the memory allocated by the original first node and set
		//its prev and next pointers to NULL
		first -> set_prev(NULL);
		first -> set_next(NULL);
		delete first;
		
	}
}


/********************************************************************************** 
 ** Description: function4 of the DoublyLinkedList class has no return type and takes
		 no parameters. It deletes the last Node in the list. 

		 The function checks if the list is empty and if so displays a
		 warning message to the user. The function locates the last Node and
		 deletes it and frees its allocated memory. The tail pointer is then
		 reassigned, along with the pointers inside the new last Node of the
		 list
 ** *******************************************************************************/ 

void DoublyLinkedList::function4()
{
	//if the list is empty
	if (head == NULL)
	{
		std::cout << "The list is empty!" << std::endl;
	}
	
	//if only one node in the list
	if (head == tail)
	{
		delete head;
		head = NULL;
		tail = NULL;
	}	

	else
	{	
		//locate the second last node in the list which is to become the last node
		Node* second_last = tail -> get_prev();

		//locate the last node in the list to be removed
		Node* last = tail;

		//set tail to the second last node, which becomes the last node now
		tail = second_last;
	
		//set next pointer of new last node to NULL
		tail -> set_next(NULL);
		
		//if now only one node in the list
		if (tail -> get_prev() == NULL)
		{
			head = tail;
		}
		
		//delete the memory allocated by the original last node and set
		//its prev and next pointers to NULL
		last -> set_prev(NULL);
		last -> set_next(NULL);
		delete last;
		
	}
}


/********************************************************************************** 
 ** Description: function5 of the DoublyLinkedList class has no return type and takes
		 no parameters. It prints the list in reverse from tail to head. If 
		 the list is empty a warning message is displayed to the user
 ** *******************************************************************************/ 

void DoublyLinkedList::function5()
{
	//direct a pointer to the end of the list
	Node *ptr = tail;
	
	if (head == NULL)
	{
		std::cout << "The list is empty!" << std::endl;
	}
		
	else
	{
		while (ptr != NULL)
		{
			//print Node data member val in current node then move to the previous
			//node, until the start of the list is reached
			std::cout << ptr -> get_val() << " ";
			ptr = ptr -> get_prev();
		}
	}
}


/********************************************************************************** 
 ** Description: function6 of the DoublyLinkedList class has no return type and takes
		 no parameters. It prints the list from head to tail. If the list is
		 empty it displays a warning message to the user
 ** *******************************************************************************/ 

void DoublyLinkedList::function6()
{
	//point to the start of the list
	Node *ptr = head;
	
	if (head == NULL)
	{
		std::cout << "The list is empty!" << std::endl;
	}
		
	else
	{	
		while (ptr != NULL)
		{
			//print Node data member val in current node then move onto the next
			//node, until the end of the list is reached
			std::cout << ptr -> get_val() << " ";
			ptr = ptr -> get_next();
		}
		
	}
}


/********************************************************************************** 
 ** Description: The print_head function of the DoublyLinkedList class takes no 
		 parameters and has no return type. It displays the int data member
		 val of the Node object the head pointer is currently pointing at
 ** *******************************************************************************/ 

void DoublyLinkedList::print_head()
{
	//if the list is empty
	if (head == NULL)
	{	
		std::cout << "The list is empty!" << std::endl;
	}

	else
	{
		int head_val =  head -> get_val();
		std::cout << "The value of the Node the head is pointing to is "
			  << head_val << std::endl;
	}
}


/********************************************************************************** 
 ** Description: The print_tail function of the DoublyLinkedList class takes no 
		 parameters and has no return type. It displays the int data member
		 val of the Node object the tail pointer is currently pointing at
 ** *******************************************************************************/ 

void DoublyLinkedList::print_tail()
{
	//if the list is empty
	if (head == NULL)
	{	
		std::cout << "The list is empty!" << std::endl;
	}

	else
	{
		int tail_val = tail -> get_val();
		std::cout << "The value of the Node the tail is pointing to is "
			  << tail_val << std::endl;
	}
}
