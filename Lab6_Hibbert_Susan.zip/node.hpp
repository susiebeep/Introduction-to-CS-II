/******************************************************************************* 
 ** Program Name: Class declaration for class Node
 ** Author:       Susan Hibbert
 ** Date:         & May 2019
 ** Description:  This program contains the function prototypes for the class Node
 ** *******************************************************************************/ 
#ifndef NODE_HPP
#define NODE_HPP

class Node
{
	private:
		int val;
		Node *prev;
		Node *next;
 
	public:
		Node();
		Node(int val1, Node *prev1, Node *next1);
		int get_val();
		void set_val(int input_val);
		Node* get_prev();
		Node* get_next();
		void set_prev(Node* input_prev);
		void set_next(Node* input_next);
};

#endif
