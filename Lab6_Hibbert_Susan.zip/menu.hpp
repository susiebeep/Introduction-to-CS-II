/******************************************************************************* 
 ** Program Name: Header file for the display_menu function used in the Doubly-Linked
		  List Program
 ** Author:       Susan Hibbert
 ** Date:         7 May 2019
 ** Description:  This program contains the function prototype for the display_menu
		  function
 ** *******************************************************************************/ 
#ifndef MENU_HPP
#define MENU_HPP
#include "doublylinkedlist.hpp"

int display_menu(DoublyLinkedList *obj);

#endif
