/******************************************************************************* 
 ** Program Name: Source code for the display_menu function used in Doubly-Linked
		  List Program
 ** Author:       Susan Hibbert
 ** Date:         7 May 2019
 ** Description:  This program contains the function definition for the display_menu
		  function which is called by the main program module of the Doubly-
		  Linked List Program.	
	
		  This function prints 8 options on the screen for the user. After
		  the user inputs their choice, it is validated by an input
		  validation function which returns their input as an integer. If the
		  user does not select a valid menu option they will be prompted until
		  they make a valid selection.				

		  If the user selects option 1, they will be prompted to enter a positive
		  integer. After the user inputs their selection, it is validated by an
		  input validation function which returns their input as an integer.
		  Their input is passed to function1 which creates a new Node object
		  at the head of the list.
		 
		  If the user selects option 2, they will be prompted to enter a positive
		  integer. After the user inputs their selection, it is validated by an
		  input validation function which returns their input as an integer.
		  Their input is passed to function2 which creates a new Node object
		  at the tail of the list.
 
		  If the user selects option 3, function3 will be called which deletes
		  the first node in the list. If the list is empty a warning message
		  will appear on screen.

		  If the user selects option 4, function4 will be called which deletes
		  the last node in the list. If the list is empty a warning message
		  will appear on screen.

		  At each menu option 1 to 4, function6 is called which prints the linked
		  list from head to tail. If the list is empty a warning message will
		  appear on screen.
		
		  If the user selects option 5, function5 will be called which prints
		  the list in reverse from tail to head. If the list is empty a warning
		  message will appear on screen.

		  If the user selects option 6, print_head() function is called which
		  prints the value of the Node the head is pointing to. If the list
		  is empty a warning message will appear on screen.		

		  If the user selects option 7, print_tail() function is called which
		  prints the value of the Node the tail is pointing to. If the list
		  is empty a warning message will appear on screen.		

		  If the user selects option 8, the program will quit.
			
		  At the end of function, the user's menu choice will be returned to
		  the main program module of the Doubly-Linked List Program
 ** Citations:    Chapter 4.5, Menu-Driven Programs, and
                  Chapter 6.9, Using Functions in a Menu-Driven Programs, Starting Out
		  With C++ Early Objects 9th Edition;
		  5.10 std::cin, extraction, and dealing with invalid text input, 
		  LearnCPP.com
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include "menu.hpp"
#include "input.hpp"
#include "doublylinkedlist.hpp"
#include "node.hpp"

int display_menu(DoublyLinkedList *obj)
{
	std::string choice;
	std::string input1;
	std::string input2;
	int valid_choice;
	int valid_choice1;
	int valid_choice2;

	std::cout << " " << std::endl;
	std::cout << " " << std::endl;
	std::cout << "********************************" << std::endl;
	std::cout << "*  DOUBLY-LINKED LIST PROGRAM  *" << std::endl;
	std::cout << "* (with extra credit - task 1) *" << std::endl;
	std::cout << "*********************************" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "Please select one of the following eight options:" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "1. Add a new node to the head" << std::endl;
	std::cout << "2. Add a new node to the tail" << std::endl; 
	std::cout << "3. Delete from head" << std::endl;	
	std::cout << "4. Delete from tail" << std::endl;
	std::cout << "5. Traverse the list reversely" << std::endl;
	std::cout << "6. Print the value of the Node the head is pointing to" << std::endl;
	std::cout << "7. Print the value of the Node the tail is pointing to" << std::endl;
	std::cout << "8. Exit" << std::endl;
	std::getline(std::cin, choice);

	//user's input is validated and converted to an integer	
	valid_choice = int_input_val(choice);

	while (valid_choice < 1 || valid_choice > 8)
	{
		std::cout << "Oops! That isn't a valid selection. Please select 1-8." << std::endl;
		std::getline(std::cin, choice);
		valid_choice = int_input_val(choice);
	}
	
	//if user chooses to exit program
	if (valid_choice == 8)
	{
		std::cout << "You selected quit. Goodbye!" << std::endl;
	}
	
	//if user chooses option 1
	if (valid_choice == 1)
	{
		std::cout << "Please enter a positive integer:" << std::endl;
		std::getline(std::cin, input1);
	
		//user's input is validated and converted to an integer
		valid_choice1 = int_input_val(input1);
	
		//call function to add a new node to the head with valid_choice1 as parameter	
		obj -> function1(valid_choice1);
	
		std::cout << " " << std::endl;
		std::cout << "Your linked list is: " << std::endl;

		//call function to print linked list from head to tail
		obj -> function6();
	}

	//if user chooses option 2
	if (valid_choice == 2)
	{
		std::cout << "Please enter a positive integer:" << std::endl;
		std::getline(std::cin, input2);
	
		//user's input is validated and converted to an integer
		valid_choice2 = int_input_val(input2);
		
		//call function to add a new node to the tail with valid_choice2 as a parameter
		obj -> function2(valid_choice2);
	
		std::cout << " " << std::endl;
		std::cout << "Your linked list is: " << std::endl;
		
		//call function to print linked list from head to tail
		obj -> function6();
	}

	//if the user chooses option 3
	if (valid_choice == 3)
	{
		std::cout << "Deleting first node in the list..." << std::endl;
			
		//call function to delete first node in the list
		//if list is empty display a warning message
		obj -> function3();

		std::cout << " " << std::endl;
		std::cout << "Your linked list is: " << std::endl;
		
		//call function to print linked list from head to tail
		obj -> function6();
	}
	
	//if the user chooses option 4
	if (valid_choice == 4)
	{
		std::cout << "Deleting last node in the list..." << std::endl;
			
		//call function to delete last node in the list
		//if list is empty display a warning message
		obj -> function4();

		std::cout << " " << std::endl;
		std::cout << "Your linked list is: " << std::endl;
		
		//call function to print linked list from head to tail
		obj -> function6();
	}

	//if the user chooses option 5
	if (valid_choice == 5)
	{
		std::cout << "Printing the list in reverse from head to tail..." << std::endl;
			
		//call function to print the list in reverse
		//if list is empty display a warning message
		obj -> function5();
	}

	//if the user chooses option 6
	if (valid_choice == 6)
	{
		obj -> print_head();
	
	}

	//if the user chooses option 7
	if (valid_choice == 7)
	{
		obj -> print_tail();	
	
	}

	return valid_choice;
}

