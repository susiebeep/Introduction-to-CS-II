/******************************************************************************* 
 ** Program Name: Class declaration for derived class LoadedDie
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This program contains the function prototypes of the child class
		  LoadedDie
 ** *******************************************************************************/ 
#ifndef LOADEDDIE_HPP
#define LOADEDDIE_HPP
#include "die.hpp"

class LoadedDie : public Die
{
	public:
		LoadedDie();
		int roll_die() const;


};

#endif
