/******************************************************************************* 
 ** Program Name: Class declaration for class Game
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This is the class declaration containing the function prototypes
		  for the Game class which implements the dice-rolling war game
 ** *******************************************************************************/ 
#include "die.hpp"
#include "loadedDie.hpp"
#include <string>
#ifndef GAME_HPP
#define GAME_HPP

class Game
{
	private:
		int round; //how many rounds will be played
		Die *dice1; //pointer to Die object
		Die *dice2; //pointer to Die object
	
	public:
		Game();
		~Game();
		int menu();
		void set_round(int input_round);
		int get_round() const;
		void set_die(int input_die, int player);
		std::string get_die(int player);
		void set_side(int input_side, int player);
		int get_side(int player);
		void play();		

};

#endif
