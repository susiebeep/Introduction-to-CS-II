/******************************************************************************* 
 ** Program Name: Source code for the display_menu function used in War Game
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This program contains the function definition for the display_menu
		  function called by the Game menu function.
		  It takes one parameter, a pointer to a Game object, which is the
		  Game object that called the Game menu function. It returns an int
		  to the main program module of the game indicating the user's menu
		  choice. 
		  The function prints two options on the screen for the user, they 
		  can press 1 to start the war game or 2 to quit. After the user
		  inputs their choice, it is validated by an input validation function
		  which returns their input as an integer. If the user did not make a 
		  valid menu choice they will be prompted until they make a valid 
		  selection.
		  If the user chose to quit, a goodbye message will be displayed,
		  0 will be returned to the Game menu function indicating the user's 
		  choice, and the program will end.
		  If the user chose to play the war game, they will be prompted for
		  the necessary information to run the game for players 1 and 2.
		  The user's input will be validated at each step with an input
		  validation function which returns their input as an integer.
		  At each step, the integer returned by the input validation function
		  will be used to set the data members of the Game object and the two
		  Die objects used in the game. Should the user enter invalid values
		  at any of these steps, the default value will be set (determined
		  by the respective member function).
		  After all the necessary information for the game is provided, a 1
		  will be returned to the Game menu function indicating that the user
		  wishes to play the game.
 ** Citations:    Chapter 4.5, Menu-Driven Programs, and
                  Chapter 6.9, Using Functions in a Menu-Driven Programs, Starting Out
		  With C++ Early Objects 9th Edition;
		  5.10 std::cin, extraction, and dealing with invalid text input, 
		  LearnCPP.com
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include "menu.hpp"
#include "game.hpp"
#include "die.hpp"
#include "loadedDie.hpp"
#include "input.hpp"

int display_menu(Game *game1)
{
	std::string choice;
	std::string input_rounds;
	std::string input_die1;
	std::string input_die2;
	std::string input_sides1;
	std::string input_sides2;
	int valid_choice;
	int val_sides1;
	int val_sides2;
	int val_die1;
	int val_die2;
	int val_rounds;

	std::cout << "Welcome to the War Game!" << std::endl;
	std::cout << "1. Start War Game" << std::endl;
	std::cout << "2. Quit program" << std::endl; 
	std::cout << "Press 1 to start or press 2 to quit then enter" << std::endl;
	std::cin >> choice;

	//user's input is validated and converted to an integer	
	valid_choice = int_input_val(choice);

	while (valid_choice < 1 || valid_choice > 2)
	{
		std::cout << "Oops! That isn't a valid selection. Please press 1 or 2." << std::endl;
		std::cin >> choice;
		valid_choice = int_input_val(choice);
	}
	
	
	if (valid_choice == 2)
	{
		std::cout << "You selected quit. Goodbye!" << std::endl;
		return 0;
	}
	
	if (valid_choice == 1)
	{
		std::cout << "Enter the number of rounds to be played: " << std::endl;
		std::cin >> input_rounds;
 
		//user's input is validated and converted to an integer
		val_rounds = int_input_val(input_rounds);	
		
		//initialize round data member of Game object
		game1 -> set_round(val_rounds);
			
		std::cout << "Enter the type of dice for player 1 " << std::endl;
		std::cout << "Press 1 for a regular dice, or press 2 for a loaded dice" << std::endl;
		std::cin >> input_die1;

		//user's input is validated and converted to an integer
		val_die1 = int_input_val(input_die1);
		
		while (val_die1 < 1 || val_die1 > 2)
		{
			std::cout << "Oops! That isn't a valid selection. Please press 1 or 2." << std::endl;
			std::cin >> input_die1;
			val_die1 = int_input_val(input_die1);
		}
	
		//Die or LoadedDie object is created depending on player 1's choice
	
		game1 -> set_die(val_die1, 1);

		std::cout << "Enter the type of dice for player 2 " << std::endl;
		std::cout << "Press 1 for a regular dice, or press 2 for a loaded dice" << std::endl;
		std::cin >> input_die2;

		//user's input is validated and converted to an integer
		val_die2 = int_input_val(input_die2);
		
		while (val_die2 < 1 || val_die2 > 2)
		{
			std::cout << "Oops! That isn't a valid selection. Please press 1 or 2." << std::endl;
			std::cin >> input_die2;
			val_die2 = int_input_val(input_die2);
		}
		
		//Die or LoadedDie object is created depending on player 2's choice
		
		game1 -> set_die(val_die2, 2);

		std::cout << "Enter the number of sides for player 1 dice: " << std::endl; 
		std::cin >> input_sides1;

		//user's input is validated and converted to an integer
		val_sides1 = int_input_val(input_sides1);
		
		//initialize N data member of Die or LoadedDie object for player 1
		game1 -> set_side(val_sides1, 1);

		std::cout << "Enter the number of sides for player 2 dice: " << std::endl; 
		std::cin >> input_sides2;

		//user's input is validated and converted to an integer
		val_sides2 = int_input_val(input_sides2);
		
		//initialize N data member of Die or LoadedDie object for player 2
		game1 -> set_side(val_sides2, 2);
		
		return 1;

	}	

}
