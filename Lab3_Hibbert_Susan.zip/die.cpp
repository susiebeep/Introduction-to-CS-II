/********************************************************************************** 
 ** Program Name: Source code for the member functions of the Die class
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This program contains the member function definitions for the Die
		  class
 ** Citations:	  Chapter 11, More about Classes and Object-Orientated Programming,
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
		  Chapter 3.10 Random Numbers, 
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
 ** *******************************************************************************/ 
#include "die.hpp"
#include <string>
#include <iostream>
#include <cstdlib>
#include <ctime>


/********************************************************************************** 
 ** Description: The default construtor for the Die class initializes the int data
		 member N to 0, which represents the number of sides of the dice,
		 and the string data member type to "Regular Dice" in a newly
		 constructed Die object
 ** *******************************************************************************/ 

Die::Die()
{
	this -> N = 0;
	this -> type = "Regular Dice";
}


/********************************************************************************** 
 ** Description: A construtor for the Die class which takes one int parameter
		 representing the number of sides on the dice and uses this value 
		 to initialize the int data member N of the Die object
 ** *******************************************************************************/ 

Die::Die(int side)
{
	this -> N = side;
}


/********************************************************************************** 
 ** Description: The get_type function takes no parameters and returns the string
		 data member type of the Die object which represents the type of
		 the dice
 ** *******************************************************************************/ 

std::string Die::get_type() const
{
	return this -> type;
}



/********************************************************************************** 
 ** Description: The get_N function takes no parameters and returns the int data
		 member N for the Die object which represents the number of sides
		 of the dice
 ** *******************************************************************************/ 

int Die::get_N() const
{
	return this -> N;
}


/********************************************************************************** 
 ** Description: The set_N function takes one int parameter representing the
		 number of sides of the dice and uses this value to set the int
		 data member N of the Die object
 ** *******************************************************************************/ 

void Die::set_N(int side)
{
	this -> N = side;
}

/********************************************************************************** 
 ** Description: The roll_die function takes no parameters and returns a random 
		 integer between 1 and N as the result of rolling the dice once.
		 The random number function rand gets seeded in the main program
		 module
 ** *******************************************************************************/ 

int Die::roll_die() const
{
	int roll;

	roll = rand() % (this -> N) + 1;

	return roll;

}








