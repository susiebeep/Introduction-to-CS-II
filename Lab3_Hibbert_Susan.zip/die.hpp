/******************************************************************************* 
 ** Program Name: Class declaration for base class Die
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This program contains the function prototypes for the parent class
		  Die 
 ** *******************************************************************************/ 
#include <string>
#ifndef DIE_HPP
#define DIE_HPP

class Die
{
	protected:
		int N; //number of sides on the individual die
		std::string type;

	public:
		Die();
		Die(int side);
		std::string get_type() const;
		int get_N() const;
		void set_N(int side);
		int roll_die() const;

};

#endif
