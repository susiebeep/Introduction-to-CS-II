/********************************************************************************** 
 ** Program Name: Source code for the member functions of the Game class
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This program contains the member function definitions for the Game
		  class
 ** Citations:	  Chapter 11, More about Classes and Object-Orientated Programming,
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
		  Chapter 3.10 Random Numbers, 
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
 ** *******************************************************************************/ 
#include "die.hpp"
#include "loadedDie.hpp"
#include "game.hpp"
#include "menu.hpp"
#include <iostream>
#include <string>

/********************************************************************************** 
 ** Description: The default construtor for the Game class initializes its data
		 member round to 0 and sets its two Die pointers to null in a newly
		 created Game object
 ** *******************************************************************************/ 

Game::Game()
{
	round = 0;
	dice1 = NULL;
	dice2 = NULL;
}


/********************************************************************************** 
 ** Description: The destructor of the Game class frees dynamically allocated memory
		 allocated to the two Die objects which were created during the running
		 of the war game
 ** *******************************************************************************/ 
Game::~Game()
{
	if (dice1 != NULL)
	{	
		delete dice1;
	}
	
	if (dice2 != NULL)
	{
		delete dice2;
	}
}
/********************************************************************************** 
 ** Description: The Game menu function calls upon a separate display_menu function
		 to print the war game's menu to the user. The display_menu function
		 takes the Game object that called the Game menu function as a
		 parameter and returns an int value indicating the user's menu choice
		 (i.e. play the war game or quit). The Game menu function itself does
		 not take any parameters but returns the user's menu choice from the
		 display_menu function to the calling program
 ** *******************************************************************************/ 

int Game::menu()
{
	int choice = display_menu(this);
	return choice;
}

/********************************************************************************** 
 ** Description: The set_round function takes one int parameter representing the
		 number of rounds to be played and uses this value to set the int
		 data member round of the Game object. If the value for the number
		 of rounds is greater than 1000, the number of rounds defaults to
		 1000, and if the value is less than 1 it default to 1 				
 ** *******************************************************************************/ 

void Game::set_round(int input_round)
{
	if (input_round > 1000)
	{
		input_round = 1000;
	}
	
	if (input_round < 1)
	{
		input_round = 1;
	}

	this -> round = input_round;
}


/********************************************************************************** 
 ** Description: The get_round function takes no parameters and returns the int data
		 member round for the Game object which represents the number of 
		 rounds to be played in the game
 ** *******************************************************************************/ 

int Game::get_round() const
{
	return this -> round;
}


/********************************************************************************** 
 ** Description: The set_die function takes two int parameters, the first representing
		 the type of the dice (regular or loaded) and the second representing
		 the player number 1 or 2.  The user will only be able to select 1 
	         for a regular dice or 2 for a loaded dice in the menu function. A new
		 Die or LoadedDie object will be created for the player depending
		 on their choice of dice and a Die pointer dice1 or dice2 will be set
		 to the newly created Die or LoadedDie object for each player
 ** *******************************************************************************/ 

void Game::set_die(int input_die, int player)
{
 	//create Die or LoadedDie object for player 1
	if (player == 1)
	{
		if (input_die == 1)
		{
			dice1 = new Die;
		}
		if (input_die == 2)
		{	
			dice1 = new LoadedDie;
		}
	}

	//create Die or LoadedDie object for player 2
	if (player == 2)
	{	
		if (input_die == 1)
		{
			dice2 = new Die;
		}
		if (input_die == 2)
		{	
			dice2 = new LoadedDie;
		}
	}
}

/********************************************************************************** 
 ** Description: The get_die function takes one int parameter representing the player
		 number 1 or 2 and returns the type of dice the player has selected
		 as a string by calling on the Die member function get_type
 ** *******************************************************************************/ 

std::string Game::get_die(int player)
{
	std::string dice_type; 
	
	if (player == 1)
	{
		if (dice1 != NULL)
		{
			dice_type = dice1 -> get_type();
		}
	}

	
	if (player == 2)
	{
		if (dice2 != NULL)
		{
			dice_type = dice2 -> get_type();
		}
	}

	return dice_type;
}


/********************************************************************************** 
 ** Description: The set_side function takes two int parameters, the first
		 representing the number of sides of the dice and the second 
		 representing the player number 1 or 2. For each player, the value
		 entered for the number of sides is used to set the int data member
		 N of the Die or LoadedDie object. If the value entered is greater
		 than 1000 the number of sides defaults to 1000, and if the value
		 entered is less than 4 the number of sides defaults to 4
 ** *******************************************************************************/ 

void Game::set_side(int input_side, int player)
{
	if (input_side > 1000)
	{
		input_side = 1000;
	}
	
	if (input_side < 4)
	{
		input_side = 4;
	}

	if (player == 1)
	{
		if (dice1 != NULL)
		{	
			dice1 -> set_N(input_side);
		}
	}


	if (player == 2)
	{
		if (dice2 != NULL)
		{	
			dice2 -> set_N(input_side);
		}
	}
}

/********************************************************************************** 
 ** Description: The get_side function takes one int parameter representing the
		 player number 1 or 2 and returns the int data member N of the Die
		 or LoadedDie object representing the number of sides the dice has
 ** *******************************************************************************/ 

int Game::get_side(int player)
{	
	if (player == 1)
	{
		if (dice1 != NULL)
		{	
			return dice1 -> get_N();
		}
	}

	if (player == 2)
	{
		if (dice2 != NULL)
		{	
			return dice2 -> get_N();
		}
	}	
}


/********************************************************************************** 
 ** Description: The play function starts the War Game. It takes no parameters and
		 does not have a return type. It compares the dice roll of the two
		 players in the game at each round. The player who rolls the higher
		 number gets one point added to their score. If the two players roll
		 the same number neither player gets a point. At each round the round
		 number is displayed, along with the side and type of die for each
		 player, the number each player rolls and their scores. After the
		 game has ran for the specified number of rounds, the final scores and
		 the winner is displayed
 ** *******************************************************************************/ 

void Game::play()
{
	int round = 0; //initializing loop counter
	int score_1 = 0; //set player 1's score to 0
	int score_2 = 0; // set player 2's score to 0

	while (round < (this -> round))
 	{
		//re-setting the die each round
		int player_1 = 0;
		int player_2 = 0;

		//round number and player dice information printed each round of the game
		std::cout << "********************ROUND " << (round + 1) << "********************" << std::endl;

		std::cout << "Player 1 is using a " << dice1 -> get_type() << " with "
			  << dice1 -> get_N() << " sides" << std::endl;


		std::cout << "Player 2 is using a " << dice2 -> get_type() << " with "
			  << dice2 -> get_N() << " sides" << std::endl;
				
		std::cout << " " << std::endl;
		std::cout << "Roll the dice!" << std::endl;
		std::cout << " " << std::endl;

		// roll the die
		player_1 = dice1 -> roll_die();
		player_2 = dice2 -> roll_die();		

		if (player_1 > player_2)
		{
			++score_1;
		}
		else
		{	
			++score_2;
		}
	
		std::cout << "Player 1 rolled a " << player_1 << " and has " << score_1 << " points" << std::endl;
	
		std::cout << "Player 2 rolled a " << player_2 << " and has " << score_2 << " points" << std::endl;
		std::cout << " " << std::endl;
		
		round++;
	}

	std::cout << "The war game is over!" << std::endl;
	std::cout << " " << std::endl;
	
	if (score_1 > score_2)
	{
		std::cout << "Player 1 is the winner with a final score of " << score_1 << " points!" << std::endl;
		std::cout << "Player 2 has a final score of " << score_2 << " points " << std::endl;
	}
	if (score_1 < score_2)
	{

		std::cout << "Player 2 is the winner with a final score of " << score_2 << " points!" << std::endl;
		std::cout << "Player 1 has a final score of " << score_1 << " points " << std::endl;
	}
	if (score_1 == score_2)
	{
		std::cout << "It's a draw! Both players have a final score of " << score_1 << " points!" << std::endl;
	}
}	

