/******************************************************************************* 
 ** Program Name: Main program module for War Game
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This is the main program module for the War Game. A Game object is 
		  created which calls the Game menu function to display the game
		  menu to the user. If the user decides to play the game, the menu
		  function will return 1 as an integer and the Game object will call
		  the play function to start the game. The random number function
		  rand used in the roll_die functions of the Die and LoadedDie classes
		  becomes seeded with a value by the srand function at the start of
		  the main program module
 ** *******************************************************************************/ 
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "die.hpp"
#include "loadedDie.hpp"
#include "game.hpp"

int main()
{
	//random number generator seed for the roll_die functions
	unsigned seed;
	seed = time(0);
	srand(seed);

	Game game1;
	int choice = game1.menu();
	
	if (choice == 1)
	{
		game1.play();	
	}

	return 0;
}
