/******************************************************************************* 
 ** Program Name: Header file for the display_menu function used in War Game
 ** Author:       Susan Hibbert
 ** Date:         15 April 2019
 ** Description:  This program contains the function prototype for the display_menu
		  function called by Game Menu function
 ** *******************************************************************************/ 
#ifndef MENU_HPP
#define MENU_HPP
#include "game.hpp"

int display_menu(Game *g1);

#endif
