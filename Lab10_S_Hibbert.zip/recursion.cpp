/********************************************************************************** 
 ** Program Name: Source code for the member functions of the class Recursion
 ** Author:       Susan Hibbert
 ** Date:         5 June 2019
 ** Description:  This program contains the member function definitions for the
		  class Recursion 
 ** Citations:	  1. Fibonacci Recursive and Non-Recursive C++, CodeProject.com
		  2. C++ Program to Find Fibonacci Numbers Using Recursion,
		    TutorialsPoint.com
 ** *******************************************************************************/ 
#include "recursion.hpp"
#include <iostream>


/********************************************************************************** 
 ** Description: The default constructor for the Recursion class. The body of the
		 constructor is empty as the Recursion class has no data members
 ** *******************************************************************************/ 

Recursion::Recursion()
{

}


/********************************************************************************** 
 ** Description: The FibonacciRec function of the Recursion class takes one int 
		 parameter N1 and uses it to calculate and return the unsigned long
		 int Fibonacci Number of N1 via recursion
 ** *******************************************************************************/ 

unsigned long int Recursion::FibonacciRec(int N1)
{
	//if int parameter is equal to 0 or 1 return the parameter
	if (N1 == 0 || N1 == 1)
	{
		return N1;
	}
	else  
	{	//recursive function call
		return (FibonacciRec(N1 - 1) + FibonacciRec(N1 - 2));
	}
	
}


