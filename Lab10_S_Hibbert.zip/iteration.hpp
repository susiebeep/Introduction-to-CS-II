/******************************************************************************* 
 ** Program Name: Class declaration for class Iteration
 ** Author:       Susan Hibbert
 ** Date:         5 June 2019
 ** Description:  This program contains the function prototypes for the class 
		  Iteration 
 ** Citations:	 1. Fibonacci Recursive and Non-Recursive C++, CodeProject.com
		 2. C++ Program to Find Fibonacci Numbers Using Iteration,
		    TutorialsPoint.com		
		 3. C++ Program to Find Fibonacci Numbers using Iteration,
		    sanfoundry.com	
 ** *******************************************************************************/ 
#ifndef ITERATION_HPP
#define ITERATION_HPP

class Iteration
{
	private:
		int N;
	public:
		Iteration(int N1); 
		unsigned long int FibonacciIt();
};

#endif
