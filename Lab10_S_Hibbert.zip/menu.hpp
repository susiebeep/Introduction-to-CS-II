/********************************************************************************** 
 ** Program Name: Header file for the display_menu function used in the Fibonacci
		  Numbers Calculation Program
 ** Author:       Susan Hibbert
 ** Date:         5 June 2019
 ** Description:  This program contains the function prototype for the display_menu
		  function
 ** *******************************************************************************/ 
#ifndef MENU_HPP
#define MENU_HPP

int display_menu();

#endif
