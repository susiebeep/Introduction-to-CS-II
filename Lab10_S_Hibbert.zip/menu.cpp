/******************************************************************************* 
 ** Program Name: Source code for the display_menu function used in the Fibonacci
		  Numbers Calculation Program
 ** Author:       Susan Hibbert
 ** Date:         5 June 2019
 ** Description:  This program contains the function definition for the
		  display_menu function which is called by the main program module
		  of the Fibonacci Numbers Calculation Program.	
	
		  The function prints two options on screen for the user. After
		  the user inputs their choice, it is validated by an input 
		  validation function which returns their input as an integer. If
		  the user does not select a valid menu option they will be prompted
		  until they make a valid selection.
		
		  If the user selects option 1, they will be asked to enter a
		  number N, representing the Nth Fibonacci Number. After the user
		  inputs the number, it is validated by an input validation function
		  which returns their input as an integer. If the user enters a
		  number out of range, they will be prompted to enter another number.
		  The Nth Fibonacci Number entered by the user will be calculated
		  via both iteration and recursion. The Fibonacci Number will be
		  displayed on screen to the user, along with the time taken to
		  calculate the number via iteration and recursion in microseconds. 

		  If the user selects option 2, the program will exit.
			
		  At the end of function, the user's menu choice will be returned
		  to the main program module of the Fibonacci Numbers Calculation
		  Program

 ** Citations:    1. Chapter 4.5, Menu-Driven Programs, and
                  2. Chapter 6.9, Using Functions in a Menu-Driven Programs, Starting 
		     Out With C++ Early Objects 9th Edition;
		  3. 5.10 std::cin, extraction, and dealing with invalid text input, 
		     LearnCPP.com
		  4. Chrono in C++, GeeksforGeeks.com
		  5. Date and Time Utilities, cppreference.com
		  6. std::chrono::duration_cast, cppreference.com
 ** *******************************************************************************/ 
#include <iostream>
#include <iomanip>
#include <string>
#include <ctime>
#include <chrono>
#include <ratio>
#include "menu.hpp"
#include "input.hpp"
#include "iteration.hpp"
#include "recursion.hpp"

int display_menu()
{
	std::string choice;
	std::string inputN;
	int valid_choice;
	int valid_inputN;

	std::cout << " " << std::endl;
	std::cout << " " << std::endl;
	std::cout << "******************************************" << std::endl;
	std::cout << "*  FIBONACCI NUMBERS CALCULATION PROGRAM *" << std::endl;
	std::cout << "******************************************" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "Please select one of the following two options:" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "1. Run the calculation" << std::endl;
	std::cout << "2. Exit" << std::endl;
	std::cout << " " << std::endl;
	std::getline(std::cin, choice);

	//user's input is validated and converted to an integer	
	valid_choice = int_input_val(choice);

	while (valid_choice < 1 || valid_choice > 2)
	{
		std::cout << "Oops! That isn't a valid selection. Please select 1 or 2"
			  << std::endl;
		std::getline(std::cin, choice);
		valid_choice = int_input_val(choice);
	}
	
	//if user chooses to exit program
	if (valid_choice == 2)
	{
		std::cout << " " << std::endl;
		std::cout << "You selected quit. Goodbye!" << std::endl;
		std::cout << " " << std::endl;
	}
	
	//if user chooses option 1
	if (valid_choice == 1)
	{	
		std::chrono::time_point<std::chrono::system_clock> starti, startr, endi, endr;	

		std::cout << " " << std::endl;
		std::cout << "Please enter a number N to find the Nth Fibonacci Number:" << std::endl;
		std::getline(std::cin, inputN);
	
		//user's input is validated and converted to an integer
		valid_inputN = int_input_val(inputN);
	
		//limit range of numbers input by user
		while (valid_inputN < 1 || valid_inputN > 90)
		{
			std::cout << "Please enter a number between 1 and 90" << std::endl;
			std::getline(std::cin, inputN);
			valid_inputN = int_input_val(inputN);
		}

	
		//create an Iteration object with N value entered by user and a Recursion object
		Iteration fibi(valid_inputN);
		Recursion fibr;
	
		//start the clock to measure the time for the iterative function to run
		starti = std::chrono::system_clock::now();

		//calculate the Fibonacci Number using iteration
		unsigned long int result1 = fibi.FibonacciIt();
	
		//stop the clock and measure the time the iterative function took
		endi = std::chrono::system_clock::now();
	
		std::chrono::duration<double, std::micro> elapsed_secondsi = endi - starti;
		
		std::cout << " " << std::endl;
		std::cout << "The " << valid_inputN << "th Fibonacci Number, calculated using iteration is: " << std::endl;
		std::cout << result1 << std::endl;
		std::cout << " " << std::endl;
		std::cout << "It took " << std::fixed << std::setprecision(2) << elapsed_secondsi.count()
			  << " microseconds to calculate the Fibonacci Number using iteration" << std::endl;

		//start the clock to measure the time for the recursive function to run
		startr = std::chrono::system_clock::now();

		//calculate the Fibonacci Number using recursion
		unsigned long int result2 = fibr.FibonacciRec(valid_inputN);

		//stop the clock and measure the time the recursive function took
		endr = std::chrono::system_clock::now();
	
		std::chrono::duration<double, std::micro> elapsed_secondsr = endr - startr;

		std::cout << " " << std::endl;
		std::cout << "The " << valid_inputN << "th Fibonacci Number, calculated using recursion is: " << std::endl;
		std::cout << result2 << " " << std::endl;		
		std::cout << " " << std::endl;
		std::cout << "It took " << std::fixed << std::setprecision(2) << elapsed_secondsr.count() 
			  << " microseconds to calculate the Fibonacci Sequence using recursion" << std::endl;
	}

	return valid_choice;
}

