/******************************************************************************* 
 ** Program Name: Class declaration for class Recursion
 ** Author:       Susan Hibbert
 ** Date:         5 June 2019
 ** Description:  This program contains the function prototypes for the class 
		  Recursion
 ** Citations:	  1. Fibonacci Recursive and Non-Recursive C++, CodeProject.com
		  2. C++ Program to Find Fibonacci Numbers Using Recursion,
		    TutorialsPoint.com
 ** *******************************************************************************/ 
#ifndef RECURSION_HPP
#define RECURSION_HPP

class Recursion
{
	public:
		Recursion();
		unsigned long int FibonacciRec(int N1);
};

#endif
