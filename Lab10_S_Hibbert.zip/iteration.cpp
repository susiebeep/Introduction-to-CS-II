/********************************************************************************** 
 ** Program Name: Source code for the member functions of the class Iteration
 ** Author:       Susan Hibbert
 ** Date:         5 June 2019
 ** Description:  This program contains the member function definitions for the
		  class Iteration 
 ** Citations:	 1. Fibonacci Recursive and Non-Recursive C++, CodeProject.com
		 2. C++ Program to Find Fibonacci Numbers Using Iteration,
		    TutorialsPoint.com	
		 3. C++ Program to Find Fibonacci Numbers using Iteration,
		    sanfoundry.com	
 ** *******************************************************************************/ 
#include "iteration.hpp"
#include <iostream>

/********************************************************************************** 
 ** Description: A constructor for the Iteration class which takes one int parameter
		 which it uses to set its int data member N upon creation of a new
		 Iteration object
 ** *******************************************************************************/ 

Iteration::Iteration(int N1)
{
	this -> N = N1;
}


/********************************************************************************** 
 ** Description: The FibonacciIt function of the Iteration class takes no parameters
	 	 and calculates and returns the unsigned long int Fibonacci Number
		 of the int data member N via iteration
 ** *******************************************************************************/ 

unsigned long int Iteration::FibonacciIt()
{
	//initializing variables for use in for loop
	unsigned long int previous = 1;
	unsigned long int current = 1;
	unsigned long int next = 1;	

	//for loop calculates Fibonacci Number	
	for (int i = 3; i <= N; i++)
	{
		next = current + previous;
		previous = current;
		current = next;
	}
		
	return next;
}

