/******************************************************************************* 
 ** Program Name: Header file for the Recursive Functions lab
 ** Author:       Susan Hibbert
 ** Date:         29 April 2019
 ** Description:  This program contains the function prototypes for the 3 recursive
		  functions defined in the Recursive Functions lab
 ** *******************************************************************************/ 
#ifndef RECURSION_HPP
#define RECURSION_HPP
#include <string>

void function1(std::string input_string);
int function2(int *array, int elements);
int function3(int N);

#endif
