/******************************************************************************* 
 ** Program Name: Header file for the display_menu function used in the Recursive
		  functions lab
 ** Author:       Susan Hibbert
 ** Date:         29 April 2019
 ** Description:  This program contains the function prototype for the display_menu
		  function
 ** *******************************************************************************/ 
#ifndef MENU_HPP
#define MENU_HPP

int display_menu();

#endif
