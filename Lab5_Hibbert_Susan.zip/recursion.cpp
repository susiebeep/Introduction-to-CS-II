/********************************************************************************** 
 ** Program Name: Source code for the Recursive Functions lab
 ** Author:       Susan Hibbert
 ** Date:         29 April 2019
 ** Description:  This program contains the function definitions for the
		  3 recursive functions defined in the Recursive Functions lab
 ** Citations:	  Chapter 14 Recursion, Starting Out With C++ Early Objects, 9th
		  Edition, Gaddis
		  7.11 Recursion, LearnCpp.com
		  Summing Numbers Recursive C++, Stack Overflow
 ** *******************************************************************************/ 
#include "recursion.hpp"
#include <string>
#include <iostream>


/********************************************************************************** 
 ** Description: function1 has no return type and takes a string parameter and
		 recursively prints the string in reverse followed by a newline
		 character. The base case is a string made up of zero characters.
		 The recursive step involves printing out the last character of the
		 string then truncating the input string and creating a substring of
		 the input string, minus the last character, and passing it to 
		 function1. The function stops once it reaches the base case then
		 adds a newline character to the end of the string
 ** *******************************************************************************/ 

void function1(std::string input_string)
{

	//base case is string made up of 0 characters
	if (input_string.length() == 0)
	{
		//print newline character at the end of the string after it has been
		//reversed
		std::cout << '\n';
	}
	else
	{	//print out the last character of the string
	
		std::cout << input_string.at((input_string.length() - 1));
		
		//create a substring of input_string which is the same string
		//minus the very last character of the input_string and pass 
		//this new truncated input_string to function1
		
		input_string = (input_string.substr(0, (input_string.length()) - 1));

		function1(input_string);
	}
}


/********************************************************************************** 
 ** Description: function2 takes a pointer to an integer array and an integer
		 representing the number of elements in the array and recursively
		 calculates the sum of the array of integers and returns the sum as
		 an int. The base case is when there are no elements in the array.
		 The recursive step involves passing the pointer to the array and 
		 elements - 1 to function2 and adding the integers in the last
		 index of the array each iteration. The function stops once it 
		 reaches the base case i.e. when there are no more elements to sum
		 in the array.
 ** *******************************************************************************/ 

int function2(int *array, int elements)
{	
	//base case is when the number of integers in the array is 0
	if (elements == 0)
	{
		return 0;
	}
	else
	{
		return (function2(array, elements - 1) + array[elements - 1]);
	}
	
}


/********************************************************************************** 
 ** Description: function3 takes an int parameter N and recursively calculates the
		 triangular number of integer N and returns it as an int. The base
		 case is 1 which is the first triangular number and the recursive
		 step is the parameter N plus the triangular number of N - 1, 
		 obtained by passing N - 1 to function3. The function stops once it
		 reaches the base case.
 ** *******************************************************************************/ 

int function3(int N)
{

	//base case is 1 as the first triangular number is 1
	if (N == 1)
	{
		return 1;
	}
	else
	{
		int num = N + function3(N - 1);
		return num;
	}

}

