/******************************************************************************* 
 ** Program Name: Main program module for Recursive Functions lab
 ** Author:       Susan Hibbert
 ** Date:         29 April 2019
 ** Description:  This is the main program module for the Recursive Functions
		  program. The display_menu function is called which provides the
		  user with a list of functions they can choose to run, or they
		  can exit the program. After the user has made their menu choice,
		  it is returned to the main program module and as long as they have
		  not selected to exit the program the menu will display on screen
		  again.
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include "recursion.hpp"
#include "menu.hpp"


int main()
{
	int choice;
	
	choice = display_menu();

	//continue to display menu while user has not selected to quit program	
	while (choice != 4)
	{
		choice = display_menu();
	}

	return 0;
}
