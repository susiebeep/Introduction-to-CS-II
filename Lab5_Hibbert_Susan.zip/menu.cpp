/******************************************************************************* 
 ** Program Name: Source code for the display_menu function used in Recursive 
		  Functions lab
 ** Author:       Susan Hibbert
 ** Date:         29 April 2019
 ** Description:  This program contains the function definition for the display_menu
		  function which is called by the main program module of the Recursive
		  Function program.	
	
		  This function prints four options on the screen for the user. After
		  the user inputs their choice, it is validated by an input
		  validation function which returns their input as an integer. If the
		  user does not select a valid menu option they will be prompted until
		  they make a valid selection.
		
		  If the user selects option 1, they will be prompted to enter a string
		  which function1 will recursively print on screen in reverse.
		 
		  If they select option 2, the user will be asked to enter the size of
		  an integer array then they will be asked to enter all the integers
		  for the array and function2 will calculate and print the recursive
		  sum of all the integers in the array. The user's input will be
		  validated and converted to an integer before being passed to function2.

		  If the user selects option 3, the user will be asked to enter an 
		  integer and function3 will recursively calculate the triangular
		  number of that integer. The user will be limited to integers between
		  1 and 10,000. The user's input will be validated and converted to an
		  integer before being passed to function3.
 
		  If the user selects option 4, the program will quit.
			
		  At the end of function, the user's menu choice will be returned to
		  the main program module of the Recursive Functions program
 ** Citations:    Chapter 4.5, Menu-Driven Programs, and
                  Chapter 6.9, Using Functions in a Menu-Driven Programs, Starting Out
		  With C++ Early Objects 9th Edition;
		  5.10 std::cin, extraction, and dealing with invalid text input, 
		  LearnCPP.com
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include "menu.hpp"
#include "input.hpp"
#include "recursion.hpp"

int display_menu()
{
	std::string choice;
	std::string input_string;
	std::string input_N;
	std::string input_total;
	std::string input_num;
	int *array = NULL;
	int valid_choice;
	int valid_choice1;
	int valid_choice2;
	int valid_choicei;

	std::cout << " " << std::endl;
	std::cout << " " << std::endl;
	std::cout << "*************************" << std::endl;
	std::cout << "*  RECURSIVE FUNCTIONS  *" << std::endl;
	std::cout << "*************************" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "Please select one of the following four options:" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "1. Run Function #1" << std::endl;
	std::cout << "2. Run Function #2" << std::endl; 
	std::cout << "3. Run Function #3" << std::endl;	
	std::cout << "4. Exit the program" << std::endl;
	std::getline(std::cin, choice);

	//user's input is validated and converted to an integer	
	valid_choice = int_input_val(choice);

	while (valid_choice < 1 || valid_choice > 4)
	{
		std::cout << "Oops! That isn't a valid selection. Please select 1-4." << std::endl;
		std::getline(std::cin, choice);
		valid_choice = int_input_val(choice);
	}
	
	//if user chooses to exit program
	if (valid_choice == 4)
	{
		std::cout << "You selected quit. Goodbye!" << std::endl;
	}
	
	//if user chooses to run function 1
	if (valid_choice == 1)
	{
		std::cout << "Please enter the string you would like to reverse:" << std::endl;
		std::getline(std::cin, input_string);
	
		std::cout << " " << std::endl;
		std::cout << "The string in reverse is: " << std::endl;

		//call function 1 to print the reverse of the string recursively
		function1(input_string);
	
	}

	//if user chooses to run function 2
	if (valid_choice == 2)
	{
		std::cout << "Please enter the total number of integers in the array:" << std::endl;
		std::getline(std::cin, input_total);
	
		//user's input is validated and converted to an integer
		valid_choice1 = int_input_val(input_total);
		

		//dynamically allocate an int array of size specified by user
		array = new int[valid_choice1];

		
		//ask user to enter all the integers in the array
		std::cout << "Please enter " << valid_choice1 << " integers for the array:" << std::endl;
		for (int i = 0; i < valid_choice1; ++i)
		{
			std::getline(std::cin, input_num);
			
			//user's input is validated and converted to an integer
			valid_choicei = int_input_val(input_num);

			//assign int value to corresponding array position
			array[i] = valid_choicei;
		}

		//call function2 to recursively calculate the sum of the array of integers
		int result2 = function2(array, valid_choice1);
		
		//Display the sum of the array of integers
		std::cout << "The sum of the array of integers is " << result2 << std::endl;
		
		//free dynamically allocated memory for int array
		delete [] array;

		array = NULL;
	}

	//if the user chooses to run function 3
	if (valid_choice == 3)
	{
		std::cout << "Please enter an integer you would like the triangular number for:" << std::endl;
		std::getline(std::cin, input_N);
			
		//user's input is validated and converted to an integer	
		valid_choice2 = int_input_val(input_N);
		
		//Setting the limit for N to 1 - 10,000
		while (valid_choice2 < 1 || valid_choice2 > 10000)
		{
			std::cout << "Oops! Please enter an integer between 1 and 10,000:" << std::endl;
			std::getline(std::cin, input_N);
			valid_choice2 = int_input_val(input_N);
		}
		
		//call function3 to calculate the triangular number recursively
		int result3 = function3(valid_choice2);

		//Display the triangular number
		std::cout << "The triangular number of " << valid_choice2 << " is " << result3 << std::endl;
	}
	
	return valid_choice;
}

