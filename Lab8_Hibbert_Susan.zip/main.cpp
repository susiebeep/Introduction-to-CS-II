/******************************************************************************* 
 ** Program Name: Main program module for Lab 8
 ** Author:       Susan Hibbert
 ** Date:         23 May 2019
 ** Description:  This is the main program module for Lab 8. In this program, 4
		  input text files containing integer values are copied into 4 int
		  arrays which are then passed to a simple linear search function.
		  After the user specifies a search value, the search results are
		  displayed on screen for each array. Afterwards, each array is
		  passed to a sort function to sort each array into ascending order
		  using the Bubble Sort algorithm. The new sorted arrays are
		  copied into output files, specified by the user, and are also
		  displayed on screen. The output files containing the sorted arrays
		  are copied into 4 new int arrays, and these new sorted arrays are
		  passed to a binary search function which runs binary search on the
		  sorted arrays and displays the new search results on screen.
 ** Citations:	  Chapter 8.3 Inputting and Displaying Array Data, Starting Out with
		  C++ Early Objects, 9th Edition, Gaddis
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include <fstream>
#include "searchsort.hpp"

int main()
{
	//declare 4 filestream objects
	std::ifstream ifs1;
	std::ifstream ifs2;
	std::ifstream ifs3;
	std::ifstream ifs4;
	
	//declare 4 int arrays to hold the values from the input files
	int array1[10];
	int array2[10];
	int array3[10];
	int array4[9];

	//4 input files
	std::string input_file1 = "early.txt";
	std::string input_file2 = "middle.txt";
	std::string input_file3 = "end.txt";
	std::string input_file4 = "original.txt";

	//initialize arrays before passing in the values from the files
	for (int i = 0; i < 10; i++)
	{	
		array1[i] = 0;
	} 

	
	for (int i = 0; i < 10; i++)
	{	
		array2[i] = 0;
	}
 

	for (int i = 0; i < 10; i++)
	{	
		array3[i] = 0;
	}


	for (int i = 0; i < 9; i++)
	{	
		array4[i] = 0;
	}

	std::cout << " " << std::endl;
	std::cout << "********************************" << std::endl;
	std::cout << "* LAB 8: SEARCHING AND SORTING *" << std::endl;
	std::cout << "********************************" << std::endl;
	std::cout << " " << std::endl;


	std::cout << "1. READ VALUES FROM FILES" << std::endl;
	std::cout << " " << std::endl;

	//read values from input file 1 into its respective array
	std::cout << "Reading values from early.txt and inputting values into array1..."
		  << std::endl;

	toArray(ifs1, input_file1, array1, 10);

	//read values from input file 2 into its respective array
	std::cout << "Reading values from middle.txt and inputting values into array2..."
		  << std::endl;

	toArray(ifs2, input_file2, array2, 10);

	//read values from input file 3 into its respective array
	std::cout << "Reading values from end.txt and inputting values into array3..."
		  << std::endl;

	toArray(ifs3, input_file3, array3, 10);

	//read values from input file 4 into its respective array
	std::cout << "Reading values from original.txt and inputting values into array4..."
		  << std::endl;

	toArray(ifs4, input_file4, array4, 9);
	
	std::cout << " " << std::endl;
	std::cout << "2. SIMPLE LINEAR SEARCH" << std::endl;
	std::cout << " " << std::endl;

	//simple linear search function to search for a target value
	simple_search(array1, array2, array3, array4);

	std::cout << " " << std::endl;
	std::cout << "3. SORTING WITH BUBBLE SORT" << std::endl;
	std::cout << " " << std::endl;

	//sort function which sorts the arrays and returns the name of the output file
	//specified by the user
	std::string output1 = sort(array1, 10);
	std::string output2 = sort(array2, 10);
	std::string output3 = sort(array3, 10);
	std::string output4 = sort(array4, 9);

	//create new arrays to store sorted values
	int sortedArray1[10];
	int sortedArray2[10];
	int sortedArray3[10];
	int sortedArray4[9];
	
	//declare 4 new filestream objects
	std::ifstream ifs5;
	std::ifstream ifs6;
	std::ifstream ifs7;
	std::ifstream ifs8;
		
	//read values from new input files (i.e. the output files from sort function) containing sorted values
	//into their respective arrays
	std::cout << "Values from early.txt have been sorted and transferred to new array..." << std::endl;
	toArray(ifs5, output1, sortedArray1, 10);

	std::cout << "Values from middle.txt have been sorted and transferred to new array..." << std::endl;
	toArray(ifs6, output2, sortedArray2, 10);

	std::cout << "Values from end.txt have been sorted and transferred to new array..." << std::endl;
	toArray(ifs7, output3, sortedArray3, 10);

	std::cout << "Values from original.txt have been sorted and transferred to new array..." << std::endl;
	toArray(ifs8, output4, sortedArray4, 9);
	
	std::cout << " " << std::endl;
	std::cout << "4. BINARY SEARCH" << std::endl;
	std::cout << " " << std::endl;

	//binary search function to search for a target value in the sorted arrays
	binary_search(sortedArray1, sortedArray2, sortedArray3, sortedArray4);

	std::cout << " " << std::endl;
	std::cout << "END OF PROGRAM" << std::endl;

	return 0;
}
