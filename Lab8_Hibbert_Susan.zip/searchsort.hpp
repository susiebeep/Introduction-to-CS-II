/******************************************************************************* 
 ** Program Name: Header file for the searching and sorting functions used in Lab 8
 ** Author:       Susan Hibbert
 ** Date:         23 May 2019
 ** Description:  This program is the header file containing the function prototypes
		  for the toArray, simple_search, sort, and binary_search functions
 ** *******************************************************************************/ 
#include <iostream>
#include <fstream>
#ifndef SEARCHSORT_HPP
#define SEARCHSORT_HPP

void toArray(std::ifstream& ifs, std::string input_file, int array[], int size);
void simple_search(int array1[], int array2[], int array3[], int array4[]);
std::string sort(int array[], int size);
void binary_search(int sortedArray1[], int sortedArray2[], int sortedArray3[], int sortedArray4[]);

#endif
