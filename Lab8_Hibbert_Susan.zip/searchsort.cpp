/**********************************************************************************
 ** Program Name: Source code for toArray, simple_search, sort and binary_search
		  functions used in Lab 8
 ** Author:       Susan Hibbert
 ** Date:         23 May 2019
 ** Description:  This program contains the function definitions for toArray, 
		  simple_search, sort, and binary_search functions
 ** Citations:	  Chapter 9 Searching, Sorting and Algorithm Analysis, Starting Out
		  With C++ Early Objects, 9th Edition, Gaddis
		  Chapter 13, Advanced File and I/O Operations, Starting Out With C++
		  Early Objects, 9th Edition, Gaddis
 ** *******************************************************************************/ 
#include "searchsort.hpp"
#include "input.hpp"
#include <iostream>
#include <string>
#include <fstream>

/********************************************************************************** 
 ** Description: The toArray function takes 4 parameters - an input file stream
		 variable, a string parameter representing the name of the input
		 file, an empty int array and an int representing the size of the
		 array. It has no return type. This function reads values from the
		 input file passed as a parameter and stores these values in the int
		 array. The values stored in the array will be unsorted and appear
		 in the same order as they are arranged in the input file
 ** *******************************************************************************/ 

void toArray(std::ifstream &ifs, std::string input_file, int array[], int size)
{
	int count = 0;
	ifs.open(input_file, std::ios::in); //open input file

	//continue to copy values into the array while the array has not been
	//filled and there are still values to be read from the input file
	while (count < size && ifs >> array[count])
	{
		count++;
	}
	
	ifs.close(); //close input file

	//display the contents of the array
	std::cout << "Here is the array: " << std::endl;
	for (int i = 0; i < size; i++)
	{
		std::cout << array[i] << " ";
	}
	
	std::cout << " " << std::endl;
	std::cout << " " << std::endl;

}

/********************************************************************************** 
 ** Description: The simple_search function searches for a target value in 4 
		 unsorted int arrays, passed as parameters to the function. It has
		 no return type. The function prompts the user to enter a target
		 value, validates the user's input, then displays whether the target
		 value is found in each int array. If the target value is found, its
		 array subscript is displayed. Otherwise, an error message is
		 displayed informing the user that the target value was not found in
		 that array. This function utilizes a linear search method to search
		 for the target value in an unsorted array of integers
 ** *******************************************************************************/ 

void simple_search(int array1[], int array2[], int array3[], int array4[])
{
	std::string input_value;	
	int target_value;

	//ask user for target value
	std::cout << "What is the target value?" << std::endl;
	std::getline(std::cin, input_value);
	std::cout << " " << std::endl;

	//user's input is validated and converted to an integer
	target_value = int_input_val(input_value);

	//search the 4 int arrays passed as parameters
	//search array1
	int size1 = 10;
	int index1 = 0;
	int position1 = -1;
	bool found1 = false;
	
	while (index1 < size1 && !found1)
	{
		if (array1[index1] == target_value)
		{	
			found1 = true;
			position1 = index1;
			std::cout << "Array1 (from early.txt): target value found in array position "
				  << position1 << std::endl;
		}
		index1++;
	}
	
	//if target value not found
	if (position1 == -1)
	{
		std::cout << "Array1 (from early.txt): target value not found " << std::endl;
	}

	//search array2
	int size2 = 10;
	int index2 = 0;
	int position2 = -1;
	bool found2 = false;
	
	while (index2 < size2 && !found2)
	{
		if (array2[index2] == target_value)
		{	
			found2 = true;
			position2 = index2;
			std::cout << "Array2 (from middle.txt): target value found in array position "
				  << position2 << std::endl;
		}
		index2++;
	}

	//if target value not found
	if (position2 == -1)
	{
		std::cout << "Array2 (from middle.txt): target value not found " << std::endl;
	}

	//search array3
	int size3 = 10;
	int index3 = 0;
	int position3 = -1;
	bool found3 = false;
	
	while (index3 < size3 && !found3)
	{
		if (array3[index3] == target_value)
		{	
			found3 = true;
			position3 = index3;
			std::cout << "Array3 (from end.txt): target value found in array position "
				  << position3 << std::endl;
		}
		index3++;
	}

	//if target value not found
	if (position3 == -1)
	{
		std::cout << "Array3 (from end.txt): target value not found " << std::endl;
	}

	//search array4
	int size4 = 9;
	int index4 = 0;
	int position4 = -1;
	bool found4 = false;
	
	while (index4 < size4 && !found4)
	{
		if (array4[index4] == target_value)
		{	
			found4 = true;
			position4 = index4;
			std::cout << "Array4 (from original.txt): target value found in array position "
				  << position4 << std::endl;
		}
		index4++;
	}
	
	//if target value not found
	if (position4 == -1)
	{
		std::cout << "Array4 (from original.txt): target value not found " << std::endl;
	}
}


/********************************************************************************** 
 ** Description: The sort function takes 2 parameters - an unsorted array of integers
		 that contains the values to be sorted and an int representing the
		 size of the array. It returns a string representing the name of the
		 output file specified by the user. The function first asks the user
		 to enter a filename they would like to output to, then it sorts the
		 values in the array in ascending order and outputs the sorted values
		 to the output file. The function then displays the sorted values on
		 screen to the user. The function uses the Bubble Sort sorting
		 algorithm to sort the values in the array in ascending order
		
 ** Citations: 	 Chapter 9.3 Introduction to Sorting Algorithms: The Bubble Sort,
		 p613 - 617, Starting Out with C++ Early Objects, 9th Edition, Gaddis
 ** *******************************************************************************/ 

std::string sort(int array[], int size)
{
	std::ofstream ofs;
	std::string output_file;	
	int temp;
	bool madeSwap;	

	//using the Bubble Sort sorting algorithm, arrange the values in the array in
	//ascending order
	do
	{
		madeSwap = false;
		for (int count = 0; count < (size - 1); count++)
		{
			if (array[count] > array[count + 1])
			{
				temp = array[count];
				array[count] = array[count + 1];
				array[count + 1] = temp;
				madeSwap = true;
			}
		}
	}
	while (madeSwap); //loop again if a swap occured on this pass

	std::cout << "Please enter the filename you would like to output to:" << std::endl;
	std::getline(std::cin, output_file);
	std::cout << " " << std::endl;	

	ofs.open(output_file, std::ios::out);		
	
	//if the output file opened successfully, copy the sorted values of the array
	//to the output file
	if (!ofs.fail())
	{
		for (int i = 0; i < size; i++)
		{
			ofs << array[i] << " ";
		}

		//display the sorted values on screen
		std::cout << "The sorted values are: " << std::endl;

		for (int count = 0; count < size; count++)
		{
			std::cout << array[count] << " ";	
		}
		std::cout << " " << std::endl;
		std::cout << " " << std::endl;
	}

	//If the output file failed to open an error message will be displayed to the user
	else
	{
		std::cout << "Output file failed to open" << std::endl;
	}

	ofs.close();
	
	return output_file;
}


/********************************************************************************** 
 ** Description: The binary_search function takes 4 parameters - 4 sorted arrays of 
		 integers organized in ascending order. It has no return type. The
		 function prompts the user to enter a target value, validates user
		 input, then displays whether the target value is found in each int
		 array. If the target value is found, its array subscript is 
		 displayed. Otherwise, an error message is displayed informing the
		 user that the target value was not found in that array. This
		 function utilizes a binary search method to search for the target
		 value in an sorted array of integers
 ** *******************************************************************************/ 

void binary_search(int sortedArray1[], int sortedArray2[], int sortedArray3[], int sortedArray4[])
{
	std::string input_value;	
	int target_value;
	
	//get target value from the user
	std::cout << "What is the target value?" << std::endl;
	std::getline(std::cin, input_value);
	std::cout << " " << std::endl;

	//user's input is validated and converted to an integer
	target_value = int_input_val(input_value);

	//search the 4 int arrays passed as parameters
	//search array1
	int size1 = 10;
	int first1 = 0; //first array element
	int last1 = size1 - 1; //last array element
	int middle1; //midpoint of search
	int position1 = -1; //position of target value
	bool found1 = false;

	while (!found1 && first1 <= last1)
	{
		//calculate midpoint
		middle1 = (first1 + last1) / 2; 
	
		if (sortedArray1[middle1] == target_value)
		{
			found1 = true;
			position1 = middle1;
			std::cout << "Sorted Array1 (from early.txt): target value found in array position "
				  << position1 << std::endl;
		}

		//if target value is in lower half
		else if (sortedArray1[middle1] > target_value)
		{	
			last1 = middle1 - 1;
		}
		
		//if target value is in upper half
		else
		{
			first1 = middle1 + 1;
		}
	}

	//if target value not found
	if (position1 == -1)
	{
		std::cout << "Sorted Array1 (from early.txt): target value not found " << std::endl;
	}

	//search array2
	int size2 = 10;
	int first2 = 0; //first array element
	int last2 = size2 - 1; //last array element
	int middle2; //midpoint of search
	int position2 = -1; //position of target value
	bool found2 = false;

	while (!found2 && first2 <= last2)
	{
		//calculate midpoint
		middle2 = (first2 + last2) / 2; 
	
		if (sortedArray2[middle2] == target_value)
		{
			found2 = true;
			position2 = middle2;
			std::cout << "Sorted Array2 (from middle.txt): target value found in array position "
				  << position2 << std::endl;
		}

		//if target value is in lower half
		else if (sortedArray2[middle2] > target_value)
		{	
			last2 = middle2 - 1;
		}
		
		//if target value is in upper half
		else
		{
			first2 = middle2 + 1;
		}
	}

	//if target value not found
	if (position2 == -1)
	{
		std::cout << "Sorted Array2 (from middle.txt): target value not found " << std::endl;
	}

	//search array3
	int size3 = 10;
	int first3 = 0; //first array element
	int last3 = size3 - 1; //last array element
	int middle3; //midpoint of search
	int position3 = -1; //position of target value
	bool found3 = false;

	while (!found3 && first3 <= last3)
	{
		//calculate midpoint
		middle3 = (first3 + last3) / 2; 
	
		if (sortedArray3[middle3] == target_value)
		{
			found3 = true;
			position3 = middle3;
			std::cout << "Sorted Array3 (from end.txt): target value found in array position "
				  << position3 << std::endl;
		}

		//if target value is in lower half
		else if (sortedArray3[middle3] > target_value)
		{	
			last3 = middle3 - 1;
		}
		
		//if target value is in upper half
		else
		{
			first3 = middle3 + 1;
		}
	}
	
	//if target value not found
	if (position3 == -1)
	{
		std::cout << "Sorted Array3 (from end.txt): target value not found " << std::endl;
	}

	//search array4
	int size4 = 9;
	int first4 = 0; //first array element
	int last4 = size4 - 1; //last array element
	int middle4; //midpoint of search
	int position4 = -1; //position of target value
	bool found4 = false;

	while (!found4 && first4 <= last4)
	{
		//calculate midpoint
		middle4 = (first4 + last4) / 2; 
	
		if (sortedArray4[middle4] == target_value)
		{
			found4 = true;
			position4 = middle4;
			std::cout << "Sorted Array4 (from original.txt): target value found in array position "
				  << position4 << std::endl;
		}

		//if target value is in lower half
		else if (sortedArray4[middle4] > target_value)
		{	
			last4 = middle4 - 1;
		}
		
		//if target value is in upper half
		else
		{
			first4 = middle4 + 1;
		}
	}
	
	//if target value not found
	if (position4 == -1)
	{
		std::cout << "Sorted Array4 (from orignal.txt): target value not found " << std::endl;
	}
}










