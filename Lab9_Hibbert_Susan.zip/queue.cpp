/********************************************************************************** 
 ** Program Name: Source code for the STL Queue Buffer function
 ** Author:       Susan Hibbert
 ** Date:         28 May 2019
 ** Description:  This program contains the function definition for the STL Queue
		  Buffer function
 ** Citations: 	  Chapter 18.6 The STL deque and queue Containers, Starting Out With
		  C++ Early Objects, 9th Edition, Gaddis
		  Chapter 16.5 Introduction to the Standard Template Library, 
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
		  std::queue, cppreference.com
		  std::queue, cplusplus.com
		  std::setprecision, cplusplus.com
 ** *******************************************************************************/ 
#include "queue.hpp"
#include <iostream>
#include <iomanip>
#include <queue>
#include <list>
#include <cstdlib>

/********************************************************************************** 
 ** Description: The buffer function takes 3 int parameters - one representing the
		 number of rounds the simulation should run for, entered by the user,
		 the second representing the percentage chance of adding a random
		 number to the end of the buffer and the third representing the
		 percentage chance of removing a random number from the front of the
		 buffer, both entered by the user. It has no return type.
		 
		 A random number between 1 and 1000 is generated called N, along
		 with another two random numbers between 1 and 100 representing the
		 outcomes of appending and removing numbers from the buffer. If the
		 outcome of appending a number is less than or equal to the
		 user-specified percentage for appending a number to the buffer then
		 N is added to the end of the buffer.  If the outcome of removing a
		 number is less than or equal to the user-specified percentage for
		 removing a number to the buffer then a number is removed from the
		 front of the buffer. Following this, the values in the buffer are 
		 displayed on screen, along with the length of the buffer and the
		 average length of the buffer. The simulation will continue for
		 the number of rounds specified by the user
 ** *******************************************************************************/ 

void buffer(int input_rounds, int input_append, int input_remove)
{
	//declare a queue of ints implemented as a list
	std::queue <int, std::list<int> > myQueue;
	
	//declare a second queue of ints implemented as a list to use later on when
	//displaying the buffer contents
	std::queue <int, std::list<int> > tempQueue;

	int count = 1; //loop counter
	int length = 0; //initialize buffer length variable
	double av_length = 0; //initialize average length variable
	
	while (count < input_rounds)
	{
		std::cout << " " << std::endl;
		std::cout << " " << std::endl;
		std::cout << "--------------------ROUND " << count 
			  << "--------------------" << std::endl;
		std::cout << " " << std::endl;
		
		//generate a random number between 1 and 1000 called N
		int N = rand() % 1000 + 1;

		//generate a random number between 1 and 100 for the appending number
		//percentage
		int append = rand() % 100 + 1;	
	
		//if the appending number percentage generated is less than or equal to the
		//user-specified percentage for appending a number to the buffer then append
		//N into the queue
		if (append <= input_append)
		{
			std::cout << "Adding the number " << N << " to the end of the buffer" 
				  << std::endl;
			myQueue.push(N);	
		}
		else
		{
			std::cout << "*** No value added to the end of the buffer ***" << std::endl;
		}
		
		//generate another random number between 1 and 100 for the removing number
		//percentage
		int remove = rand() % 100 + 1;	

		//if the removing number percentage generated is less than or equal to the
		//user-specified percentage for removing a number to the buffer then remove
		//N from the queue
		if (remove <= input_remove)
		{
			if (myQueue.empty())
			{
				std::cout << " " << std::endl;
				std::cout << "The buffer is empty!" << std::endl;
			}
			else
			{
				std::cout << " " << std::endl;
				std::cout << "Removing the number " << myQueue.front() 
					  << " from the front of the buffer" << std::endl;
				myQueue.pop();
			}
		}
		
		else
		{
			std::cout << " " << std::endl;
			std::cout << "*** No value removed from the front of the buffer ***" << std::endl;
		}

		//display the buffer contents
		if (myQueue.empty())
		{
			std::cout << " " << std::endl;
			std::cout << "The buffer is empty!" << std::endl;
		}

		//pop off each value in myQueue and add to tempQueue, then once all the values have
		//been popped off myQueue swap the contents with tempQueue to restore its
		//original contents
		else
		{
			std::cout << " " << std::endl;
			std::cout << "The current values in the buffer are: " << std::endl;

			while (!myQueue.empty())
			{
				std::cout << myQueue.front() << " ";
				tempQueue.push(myQueue.front());
				myQueue.pop();
			}
		
			std::cout << " " << std::endl;
		
			//once all of myQueue values have been popped off, swap with tempQueue
			//to restore its contents
			myQueue.swap(tempQueue);
		}	

		//output the length of the buffer
		length = myQueue.size();

		std::cout << " " << std::endl;
		std::cout << "The length of the buffer is " << length << " elements" << std::endl;

		//output the average length of the buffer
		av_length = (av_length * (count - 1) + length) / count;

		std::cout << " " << std::endl;
		std::cout << "The average length of the buffer is " << std::fixed 
			  << std::setprecision(2) <<av_length << " elements"  << std::endl;

		//increment loop counter
		count++;
	}
}
