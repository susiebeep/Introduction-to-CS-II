/******************************************************************************* 
 ** Program Name: Main program module for Stack and Queue STL Containers Program
 ** Author:       Susan Hibbert
 ** Date:         28 May 2019
 ** Description:  This is the main program module for the Stack and Queue STL
		  Containers Program. The display_menu function is called which
		  provides the user with a choice of menu options, or they can
		  exit the program. After the user has made their menu choice, it
		  is returned to the main program module and as long as they have
		  not selected to quit the program the menu will display on screen
		  again. The random number function used in the buffer simulation
		  function becomes seeded with a value by the srand function at the
		  start of the main program module
 ** *******************************************************************************/ 
#include <iostream>
#include "menu.hpp"
#include <cstdlib>
#include <ctime>

int main()
{
	int choice;

	//random number generator seed for buffer simulation function
	unsigned seed;
	seed = time(0);
	srand(seed);
	
	choice = display_menu();

	//continue to display menu while user has not selected to quit program	
	while (choice != 3)
	{
		choice = display_menu();
	}

	return 0;
}
