/******************************************************************************* 
 ** Program Name: Source code for the display_menu function used in the Stack 
		  and Queue STL Containers Program
 ** Author:       Susan Hibbert
 ** Date:         28 May 2019
 ** Description:  This program contains the function definition for the 
		  display_menu function which is called by the main program module
		  of the Stack and Queue STL Containers Program.	
	
		  This function prints 3 options on the screen for the user. After
		  the user inputs their choice, it is validated by an input
		  validation function which returns their input as an integer. If
		  the user does not select a valid menu option they will be 
		  prompted until they make a valid selection.				

		  If the user selects option 1, they will be prompted to enter
		  a number of rounds along with two percentage values for the
		  buffer simulation. After the user inputs each value, it is
		  validated by an input validation function which returns
		  their input as an integer. The buffer function is then called
		  which runs the buffer simulation.
		 
		  If the user selects option 2, the user is asked to enter a 
		  string and the palindrome function is called which creates the
		  palindrome of the string and displays it on screen. 
 
		  If the user selects option 3, the program will exit.
			
		  At the end of function, the user's menu choice will be returned
		  to the main program module of the Stack and Queue STL Containers
		  Program

 ** Citations:    Chapter 4.5, Menu-Driven Programs, and
                  Chapter 6.9, Using Functions in a Menu-Driven Programs, Starting 
		  Out With C++ Early Objects 9th Edition;
		  5.10 std::cin, extraction, and dealing with invalid text input, 
		  LearnCPP.com
 ** *******************************************************************************/ 
#include <iostream>
#include <string>
#include "menu.hpp"
#include "input.hpp"
#include "stack.hpp"
#include "queue.hpp"

int display_menu()
{
	std::string choice;
	std::string input1a;
	std::string input1b;
	std::string input1c;
	std::string input2;
	int valid_choice;
	int valid_choice1a;
	int valid_choice1b;
	int valid_choice1c;

	std::cout << " " << std::endl;
	std::cout << " " << std::endl;
	std::cout << "*******************************************" << std::endl;
	std::cout << "*  STACK AND QUEUE STL CONTAINERS PROGRAM *" << std::endl;
	std::cout << "*******************************************" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "Please select one of the following three options:" << std::endl;
	std::cout << " " << std::endl;
	std::cout << "1. QUEUE - Run buffer simulation" << std::endl;
	std::cout << "2. STACK - Run palindrome function" << std::endl; 
	std::cout << "3. Exit" << std::endl;
	std::cout << " " << std::endl;
	std::getline(std::cin, choice);

	//user's input is validated and converted to an integer	
	valid_choice = int_input_val(choice);

	while (valid_choice < 1 || valid_choice > 3)
	{
		std::cout << "Oops! That isn't a valid selection. Please select 1-3" << std::endl;
		std::getline(std::cin, choice);
		valid_choice = int_input_val(choice);
	}
	
	//if user chooses to exit program
	if (valid_choice == 3)
	{
		std::cout << " " << std::endl;
		std::cout << "You selected quit. Goodbye!" << std::endl;
	}
	
	//if user chooses option 1
	if (valid_choice == 1)
	{
		std::cout << " " << std::endl;
		std::cout << "Enter the number of rounds to be simulated:" << std::endl;
		std::getline(std::cin, input1a);
		
		//user's input is validated and converted to an integer
		valid_choice1a = int_input_val(input1a);
	
		//store number of rounds in rounds variable
		int rounds = valid_choice1a;	
	
		std::cout << " " << std::endl;
		std::cout << "Enter the percentage chance to append a randomly generated number to the end of the buffer:" << std::endl;
		std::getline(std::cin, input1b);

		//user's input is validated and converted to an integer
		valid_choice1b = int_input_val(input1b);

		//store append percentage in append variable
		int append = valid_choice1b;		

		std::cout << " " << std::endl;
		std::cout << "Enter the percentage chance to remove a randomly generated number from the front of the buffer:" << std::endl;
		std::getline(std::cin, input1c);

		//user's input is validated and converted to an integer
		valid_choice1c = int_input_val(input1c);
		
		//store percentage in remove variable
		int remove = valid_choice1c;		
		
		//call buffer function
		buffer(rounds, append, remove);
	}

	//if user chooses option 2
	if (valid_choice == 2)
	{
		std::cout << " " << std::endl;
		std::cout << "Please enter a string:" << std::endl;
		std::getline(std::cin, input2);
	
		//call palindrome function
		std::string output = palindrome(input2);
	
		std::cout << "The pallindrome is " << output << std::endl;
	}

	return valid_choice;
}

