/******************************************************************************* 
 ** Program Name: Header file for the STL Queue Buffer function
 ** Author:       Susan Hibbert
 ** Date:         28 May 2019
 ** Description:  This program contains the function prototype for the STL Queue
		  Buffer function
 ** *******************************************************************************/ 
#ifndef QUEUE_HPP
#define QUEUE_HPP
#include <queue>

void buffer(int input_rounds, int input_append, int input_remove);

#endif
