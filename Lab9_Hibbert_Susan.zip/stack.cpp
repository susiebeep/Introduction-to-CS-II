/********************************************************************************** 
 ** Program Name: Source code for the STL Stack Palindrome function
 ** Author:       Susan Hibbert
 ** Date:         28 May 2019
 ** Description:  This program contains the function definition for the STL Stack
		  Palindrome function
 ** Citations: 	  Chapter 18.3 The Stack STL Container, Starting Out With C++ 
		  Early Objects, 9th Edition, Gaddis
		  Chapter 8.12 Vectors, Starting Out With C++ Early Objects, 9th
		  Edition, Gaddis
		  Chapter 16.5 Introduction to the Standard Template Library, 
		  Starting Out With C++ Early Objects, 9th Edition, Gaddis
		  How to construct a std::string from a std::vector<char>, Stack
		  Overflow
 ** *******************************************************************************/ 
#include "stack.hpp"
#include <iostream>
#include <string>
#include <stack>
#include <vector>


/********************************************************************************** 
 ** Description: The palindrome function takes one string parameter representing
		 the string entered by the user and returns a string in the form of
		 the original string concatenated with the string in reverse order
		 (the palindrome). The function first adds the individual characters
		 of the input string sequentially to the stack and displays the
		 string, then pops off the characters one by one and displays the
		 reversed string. The function then returns the original string
		 concatenated with its reversed string to the calling program
 ** *******************************************************************************/ 

std::string palindrome(std::string input_string)
{
	//declare a stack of chars implemented as a vector
	std::stack <char, std::vector<char> > myStack;

	//add user's string sequentially to the stack and display on screen
	std::cout << " " << std::endl;
	std::cout << "Adding the following string to the stack: " << std::endl;

	for (int i = 0; i < input_string.length(); i++)
	{
		std::cout << input_string.at(i);
		myStack.push(input_string.at(i));
	}
	
	std::cout << " " << std::endl;
	std::cout << " " << std::endl;

	//declare a vector of chars to store the popped off characters from the user's
	//string
	std::vector <char> reverse_vect;

	//pop off the characters in the string from the stack one by one, add them
	//to reverse_vect and display
	std::cout << "Now popping the string from the stack: " << std::endl;
	while(!myStack.empty())
	{
		std::cout << myStack.top();
		reverse_vect.push_back(myStack.top());
 		myStack.pop();
	}

	std::cout << " " << std::endl;
	std::cout << " " << std::endl;

	//convert reverse_vect char vector to a string
	std::string reverse_string(reverse_vect.begin(), reverse_vect.end());
	
	//return the palindrome (user's string concatenated with popped off string)
	return input_string + reverse_string;
	
}
