/******************************************************************************* 
 ** Program Name: Header file for the STL Stack Palindrome function
 ** Author:       Susan Hibbert
 ** Date:         28 May 2019
 ** Description:  This program contains the function prototype for the STL Stack
		  Palindrome function
 ** *******************************************************************************/ 
#ifndef STACK_HPP
#define STACK_HPP
#include <string>
#include <stack>

std::string palindrome(std::string input_string);

#endif
